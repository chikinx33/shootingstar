import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import 'engine.dart';

class BattlePainter extends CustomPainter {
  final GameEngine game;
  final ui.Image? shipImage, enemyImage, bossImage, terrainImage;
  final bool reducedEffects;
  BattlePainter(
    this.game, {
    this.shipImage,
    this.enemyImage,
    this.bossImage,
    this.terrainImage,
    this.reducedEffects = false,
  });

  // Preserve each original silhouette and alpha. Rotation happens at the actor
  // transform so every sprite shares the same upward-facing source convention.
  void _sprite(Canvas canvas, ui.Image image, double size) {
    final scale = size / math.max(image.width, image.height);
    canvas.drawImageRect(
      image,
      Rect.fromLTWH(0, 0, image.width.toDouble(), image.height.toDouble()),
      Rect.fromCenter(
        center: Offset.zero,
        width: image.width * scale,
        height: image.height * scale,
      ),
      Paint()..filterQuality = FilterQuality.medium,
    );
  }

  static const teal = Color(0xFF65FFE1), amber = Color(0xFFFFB35A);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 420, size.height / 720);
    final background = [
      const Color(0xFF071321),
      const Color(0xFF17112D),
      const Color(0xFF201018),
    ][game.stageIndex.clamp(0, 2)];
    canvas.drawRect(
      const Rect.fromLTWH(0, 0, 420, 720),
      Paint()..color = background,
    );
    if (terrainImage != null) {
      final tile = terrainImage!;
      for (double x = -(game.camera.dx % 420); x < 420; x += 420) {
        for (double y = -(game.camera.dy % 420); y < 720; y += 420) {
          canvas.drawImageRect(
            tile,
            Rect.fromLTWH(0, 0, tile.width.toDouble(), tile.height.toDouble()),
            Rect.fromLTWH(x, y, 420, 420),
            Paint(),
          );
        }
      }
      canvas.drawRect(
        const Rect.fromLTWH(0, 0, 420, 720),
        Paint()..color = const Color(0xFF071321).withValues(alpha: .25),
      );
    }
    if (game.stageIndex > 0 && game.hazardPhase > 8) {
      final p = Paint()
        ..color =
            (game.stageIndex == 1
                    ? const Color(0xFFBA8AFF)
                    : const Color(0xFFFF6A79))
                .withValues(alpha: game.hazardActive ? .26 : .09);
      if (game.stageIndex == 1) {
        canvas.drawRect(Rect.fromLTWH(game.hazardX - 27, 0, 54, 720), p);
        canvas.drawLine(
          Offset(game.hazardX, 0),
          Offset(game.hazardX, 720),
          Paint()
            ..color = const Color(0xFFCCABFF)
                .withValues(alpha: game.hazardActive ? .8 : .25)
            ..strokeWidth = 2,
        );
      } else {
        canvas.drawCircle(
          const Offset(210, 360),
          145,
          p
            ..style = PaintingStyle.stroke
            ..strokeWidth = 38,
        );
      }
    }
    canvas.translate(-game.camera.dx, -game.camera.dy);
    if (game.bossWarning) {
      final at = game.boss!.position;
      final delta = game.position - at;
      final direction = delta.distance > .01
          ? delta / delta.distance
          : const Offset(0, 1);
      canvas.drawLine(
        at,
        at + direction * 400,
        Paint()
          ..color = const Color(0xFFFF5566).withValues(alpha: .35)
          ..strokeWidth = game.bossPattern == 2 ? 45 : 4,
      );
    }
    for (final supply in game.supplies) {
      final color = [
        const Color(0xFF71ED8D),
        teal,
        amber,
        const Color(0xFFFFCD59),
      ][supply.kind];
      canvas.drawCircle(
        supply.position,
        16,
        Paint()..color = color.withValues(alpha: .24),
      );
      final text = TextPainter(
        text: TextSpan(
          text: ['+', 'M', '!', '★'][supply.kind],
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w900,
            fontSize: 23,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout();
      text.paint(
        canvas,
        supply.position - Offset(text.width / 2, text.height / 2),
      );
    }
    if ((game.upgrades['guardian'] ?? 0) > 0) {
      final radius =
          (game.evolved.contains('guardian') ? 95.0 : 62.0) * game.areaFactor;
      for (int i = 0; i < 4; i++) {
        final angle = game.elapsed * 3 + i * math.pi / 2;
        final at =
            game.position + Offset(math.cos(angle), math.sin(angle)) * radius;
        canvas.drawCircle(at, 10, Paint()..color = teal.withValues(alpha: .7));
      }
    }
    for (final crystal in game.crystals) {
      canvas.drawPath(
        Path()
          ..moveTo(crystal.dx, crystal.dy - 5)
          ..lineTo(crystal.dx + 3, crystal.dy)
          ..lineTo(crystal.dx, crystal.dy + 5)
          ..lineTo(crystal.dx - 3, crystal.dy)
          ..close(),
        Paint()..color = teal.withValues(alpha: .85),
      );
    }
    for (final shot in game.shots) {
      final color = shot.kind == 4
          ? const Color(0xFFFF677E)
          : shot.kind == 1
          ? amber
          : shot.kind == 3
          ? const Color(0xFFBF96FF)
          : teal;
      if (shot.kind == 3 || shot.kind == 5) {
        canvas.drawCircle(
          shot.position,
          shot.radius,
          Paint()..color = color.withValues(alpha: shot.kind == 5 ? .15 : .2),
        );
        canvas.drawCircle(
          shot.position,
          shot.kind == 3 ? 7 : 12,
          Paint()
            ..color = color.withValues(alpha: .65)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5,
        );
      } else {
        final velocity = shot.velocity.distance > 0
            ? shot.velocity / shot.velocity.distance
            : Offset.zero;
        canvas.drawLine(
          shot.position - velocity * (shot.kind == 0 ? 12 : 7),
          shot.position,
          Paint()
            ..color = color
            ..strokeWidth = shot.kind == 0 ? 2.5 : 4
            ..strokeCap = StrokeCap.round,
        );
        if (!reducedEffects) {
          canvas.drawCircle(
            shot.position,
            shot.radius * 2,
            Paint()..color = color.withValues(alpha: .13),
          );
        }
      }
    }
    for (final e in game.enemies) {
      canvas.save();
      canvas.translate(e.position.dx, e.position.dy);
      final rotation =
          math.atan2(
            game.position.dy - e.position.dy,
            game.position.dx - e.position.dx,
          ) +
          math.pi / 2;
      canvas.rotate(rotation);
      final color = e.kind == 3
          ? const Color(0xFFFF6F85)
          : e.kind == 2
          ? const Color(0xFFDB9CFF)
          : amber;
      final r = e.radius;
      final sprite = e.kind == 3 ? bossImage : enemyImage;
      if (sprite != null) {
        if (e.kind == 2) {
          canvas.drawCircle(
            Offset.zero,
            r * 1.15,
            Paint()
              ..color = const Color(0xFFDB9CFF).withValues(alpha: .6)
              ..style = PaintingStyle.stroke
              ..strokeWidth = 2,
          );
        }
        _sprite(canvas, sprite, r * (e.kind == 3 ? 3.0 : 2.9));
      } else {
        final path = Path()
          ..moveTo(0, -r)
          ..lineTo(r, -r * .25)
          ..lineTo(r * .7, r)
          ..lineTo(0, r * .55)
          ..lineTo(-r * .7, r)
          ..lineTo(-r, -r * .25)
          ..close();
        canvas.drawPath(path, Paint()..color = color.withValues(alpha: .18));
        canvas.drawPath(
          path,
          Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = e.kind == 3 ? 2.5 : 1.5,
        );
        canvas.drawCircle(
          Offset.zero,
          e.kind == 3 ? 9 : 3,
          Paint()..color = color,
        );
      }
      if (e.kind == 3) {
        canvas.drawCircle(
          Offset.zero,
          r * 1.25,
          Paint()
            ..color = color.withValues(alpha: .15)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1,
        );
      }
      canvas.restore();
      if (e.kind >= 2 && e.hp < e.maxHp) {
        canvas.drawRRect(
          RRect.fromRectAndRadius(
            Rect.fromLTWH(
              e.position.dx - e.radius,
              e.position.dy - e.radius - 9,
              e.radius * 2,
              3,
            ),
            const Radius.circular(2),
          ),
          Paint()..color = Colors.white12,
        );
        canvas.drawRect(
          Rect.fromLTWH(
            e.position.dx - e.radius,
            e.position.dy - e.radius - 9,
            e.radius * 2 * (e.hp / e.maxHp).clamp(0, 1),
            3,
          ),
          Paint()..color = color,
        );
      }
    }
    final droneAt =
        game.position +
        Offset(math.cos(game.elapsed * 2), math.sin(game.elapsed * 2)) * 34;
    if ((game.upgrades['drone'] ?? 0) > 0) {
      canvas.drawCircle(
        game.position,
        34,
        Paint()
          ..color = teal.withValues(alpha: .09)
          ..style = PaintingStyle.stroke,
      );
    }
    if ((game.upgrades['drone'] ?? 0) > 0) {
      canvas.drawCircle(droneAt, 5, Paint()..color = teal);
    }
    if ((game.upgrades['drone'] ?? 0) > 0) {
      canvas.drawCircle(
        droneAt,
        9,
        Paint()..color = teal.withValues(alpha: .16),
      );
    }
    canvas.save();
    canvas.translate(game.position.dx, game.position.dy);
    canvas.rotate(game.angle + math.pi / 2);
    if (game.input.distance > .05) {
      final flame = Path()
        ..moveTo(-5, 10)
        ..lineTo(0, 24 + math.sin(game.elapsed * 40) * 6)
        ..lineTo(5, 10)
        ..close();
      canvas.drawPath(flame, Paint()..color = teal.withValues(alpha: .7));
    }
    if (shipImage != null) {
      _sprite(canvas, shipImage!, 56);
    } else {
      final path = Path()
        ..moveTo(0, -19)
        ..lineTo(15, 14)
        ..lineTo(5, 9)
        ..lineTo(0, 13)
        ..lineTo(-5, 9)
        ..lineTo(-15, 14)
        ..close();
      canvas.drawPath(path, Paint()..color = const Color(0xFF163F4A));
      canvas.drawPath(
        path,
        Paint()
          ..color = teal
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2,
      );
      canvas.drawLine(
        const Offset(0, -10),
        const Offset(0, 5),
        Paint()
          ..color = Colors.white
          ..strokeWidth = 3,
      );
    }
    if (game.hurtFlash > 0) {
      canvas.drawCircle(
        Offset.zero,
        24,
        Paint()
          ..color = Colors.white.withValues(alpha: game.hurtFlash * .35)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3,
      );
    }
    canvas.restore();
    if (!reducedEffects) {
      for (final p in game.sparks) {
        canvas.drawCircle(
          p.position,
          1.5 + p.life * 2,
          Paint()
            ..color = (p.kind == 0 ? amber : teal).withValues(
              alpha: p.life.clamp(0, 1),
            ),
        );
      }
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant BattlePainter oldDelegate) => true;
}
