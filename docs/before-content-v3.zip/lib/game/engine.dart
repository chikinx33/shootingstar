import 'dart:math' as math;
import 'dart:ui';

import '../data/content.dart' as content;
import 'survival_skills.dart';

class UpgradeChoice {
  final String id, title, description, iconKey;
  final bool evolution;
  const UpgradeChoice(
    this.id,
    this.title,
    this.description,
    this.iconKey, {
    this.evolution = false,
  });
}

class Foe {
  Offset position;
  double hp, maxHp, speed, radius, phase = 0;
  final int kind;
  Foe(this.position, this.hp, this.speed, this.radius, this.kind) : maxHp = hp;
}

class Shot {
  Offset position, velocity;
  double life, damage, radius, hitCooldown = 0;
  final int kind;
  Shot(
    this.position,
    this.velocity,
    this.damage,
    this.kind, {
    this.life = 2,
    this.radius = 3,
  });
}

class Spark {
  Offset position, velocity;
  double life;
  final int kind;
  Spark(this.position, this.velocity, this.life, this.kind);
}

class Supply {
  Supply(this.position, this.kind);
  Offset position;
  final int kind; // 0 repair, 1 magnet, 2 bomb, 3 boss chest
}

class GameEngine {
  final int stageIndex,
      shipIndex,
      attackLevel,
      hullLevel,
      magnetLevel,
      equipmentIndex;
  final bool training;
  final bool challenge;
  final double gearDamage, gearHull;
  final Map<String, int> passives = {};
  final Set<String> evolved = {};
  final List<Supply> supplies = [];
  int bossesDefeated = 0, _bossWave = 0, chests = 0;
  double _supplyClock = 18, _guardian = 0, _lightning = 0;
  String pickupNotice = '';
  double noticeTime = 0;
  static const worldWidth = 1800.0, worldHeight = 2400.0;
  Offset get camera => Offset(
    (position.dx - 210).clamp(0, worldWidth - 420),
    (position.dy - 360).clamp(0, worldHeight - 720),
  );
  int get weaponCount => upgrades.keys
      .where((id) => survivalSkills.any((s) => s.id == id && !s.passive))
      .length;
  double get cooldownFactor => 1 - (passives['cooldown'] ?? 0) * .07;
  double get areaFactor => 1 + (passives['area'] ?? 0) * .12;
  double get durationFactor => 1 + (passives['duration'] ?? 0) * .2;
  int get wave => 1 + elapsed ~/ 30;
  int get requiredBosses => training ? 1 : 3;
  final math.Random random;
  void Function(String)? onEvent;
  Offset position = const Offset(900, 1200), input = Offset.zero;
  double angle = -math.pi / 2,
      elapsed = 0,
      hp = 100,
      maxHp = 100,
      xp = 0,
      xpNeeded = 10;
  int level = 1, kills = 0;
  bool paused = false, finished = false, victory = false;
  List<UpgradeChoice> choices = [];
  final Map<String, int> upgrades = {'gun': 1};
  final List<Foe> enemies = [];
  final List<Shot> shots = [];
  final List<Offset> crystals = [];
  final List<Spark> sparks = [];
  double _spawn = 0,
      _gun = 0,
      _missile = 0,
      _drone = 0,
      _side = 0,
      _mine = 0,
      _trail = 0,
      _hurt = 0,
      _audio = 0,
      _bossFire = 0;
  bool _bossSpawned = false;
  GameEngine({
    required this.stageIndex,
    required this.shipIndex,
    required this.attackLevel,
    required this.hullLevel,
    required this.magnetLevel,
    required this.equipmentIndex,
    int? seed,
    this.training = false,
    this.challenge = false,
    this.gearDamage = 0,
    this.gearHull = 0,
  }) : random = math.Random(seed) {
    maxHp =
        ship.health *
        (1 + gearHull) *
        (1 + hullLevel * .12) *
        (equipmentIndex == 0
            ? 1.2
            : equipmentIndex == 1
            ? .9
            : 1);
    hp = maxHp;
  }
  content.ShipSpec get ship =>
      content.ships[shipIndex.clamp(0, content.ships.length - 1)];
  double get duration => training
      ? 45
      : content.stages[stageIndex.clamp(0, content.stages.length - 1)].duration
            .toDouble();
  double get damageFactor =>
      (1 + attackLevel * .08 + gearDamage) *
      (1 + (passives['attack'] ?? 0) * .1) *
      ship.damage *
      (equipmentIndex == 1 ? 1.2 : 1);
  double get moveSpeed =>
      ship.speed *
      (equipmentIndex == 2 ? 1.05 : 1) *
      (1 + (passives['speed'] ?? 0) * .08);
  double get collectionRadius =>
      (55 * (1 + magnetLevel * .15) + (passives['magnet'] ?? 0) * 28) *
      (equipmentIndex == 2 ? 1.7 : 1);
  Foe? get boss {
    for (final e in enemies) {
      if (e.kind == 3) return e;
    }
    return null;
  }

  double get bossHealth => boss == null ? 0 : boss!.hp / boss!.maxHp;
  bool get bossSpawned => _bossSpawned;
  int get bossPattern => (_bossWave - 1 + stageIndex) % 3;
  bool get bossCharging =>
      boss != null && bossPattern == 2 && boss!.phase % 6 > 5;
  bool get bossWarning =>
      boss != null &&
      (bossPattern == 2
          ? boss!.phase % 6 > 4 && boss!.phase % 6 <= 5
          : _bossFire < .55);
  double get hurtFlash => _hurt;
  String get statusText => boss != null
      ? '거대 함선 · 코어를 파괴하세요'
      : stageIndex == 1
      ? '이온 폭풍 · 빛나는 세로 영역 주의'
      : stageIndex == 2
      ? '중력 파동 · 붉은 고리에서 벗어나세요'
      : '성운 외곽 · 적 포위를 돌파하세요';
  double get hazardPhase => elapsed % 14;
  double get hazardX => 70 + ((elapsed ~/ 14) * 113 % 280).toDouble();
  bool get hazardActive => hazardPhase > 11;
  void setPaused(bool value) {
    if (!finished) {
      paused = value;
      input = Offset.zero;
    }
  }

  void abandon() {
    finished = true;
    victory = false;
    input = Offset.zero;
  }

  void _event(String event) {
    if (event != 'shoot' || _audio <= 0) {
      onEvent?.call(event);
      if (event == 'shoot') _audio = .18;
    }
  }

  Offset _unit(Offset v) =>
      v.distance < .001 ? const Offset(0, -1) : v / v.distance;
  Offset _direction(double a) => Offset(math.cos(a), math.sin(a));
  void update(double delta) {
    if (finished ||
        paused ||
        choices.isNotEmpty ||
        !delta.isFinite ||
        delta <= 0) {
      return;
    }
    final dt = delta.clamp(0.0, .05);
    elapsed += dt;
    noticeTime = math.max(0, noticeTime - dt);
    _updateSupplies(dt);
    _audio -= dt;
    _hurt -= dt;
    final movement = input.distance > 1 ? _unit(input) : input;
    position += movement * moveSpeed * dt;
    position = Offset(
      position.dx.clamp(32.0, worldWidth - 32),
      position.dy.clamp(32.0, worldHeight - 32),
    );
    if (movement.distance > .05) {
      final target = math.atan2(movement.dy, movement.dx);
      final diff = math.atan2(
        math.sin(target - angle),
        math.cos(target - angle),
      );
      angle += diff * math.min(1, dt * 9);
    }
    _spawn -= dt;
    if (_spawn <= 0 && elapsed < duration && enemies.length < 220) {
      _spawn = math.max(.22, .85 - elapsed / duration * .45);
      final count =
          3 + math.min(5, wave ~/ 2) + stageIndex + (challenge ? 2 : 0);
      for (int i = 0; i < count && enemies.length < 220; i++) {
        _spawnEnemy();
      }
    }
    final nextBossAt = training ? 29.0 : duration * (_bossWave + 1) / 3 - 12;
    if (_bossWave < requiredBosses && boss == null && elapsed >= nextBossAt) {
      _bossWave++;
      _bossSpawned = true;
      enemies.add(
        Foe(
          position + const Offset(0, -320),
          (training ? 170 : 350 + stageIndex * 150 + _bossWave * 180) *
              (challenge ? 1.4 : 1),
          30 + _bossWave * 3,
          34,
          3,
        ),
      );
      pickupNotice = 'WARNING · 보스 $_bossWave / $requiredBosses';
      noticeTime = 4;
      _event('boss');
    }
    _weapons(dt);
    for (final e in enemies) {
      e.phase += dt;
      if (e.kind != 3 && (e.position - position).distance > 650) {
        e.position = _spawnPosition();
      }
      final toward = _unit(position - e.position);
      e.position +=
          toward * e.speed * dt * (e.kind == 3 && bossCharging ? 4 : 1);
      if (e.kind == 1) {
        e.position +=
            Offset(-toward.dy, toward.dx) * math.sin(e.phase * 5) * 25 * dt;
      }
      if ((e.position - position).distance < e.radius + 12 && _hurt <= 0) {
        _damage(
          e.kind == 3
              ? 20
              : e.kind == 2
              ? 15
              : 9,
        );
        e.position -= toward * 24;
      }
    }
    final currentBoss = boss;
    _bossFire -= dt;
    if (currentBoss != null && _bossFire <= 0) {
      _bossFire = math.max(.9, 2.3 - _bossWave * .25);
      final count = bossPattern == 1 ? 7 : 10 + stageIndex * 2;
      final aimed = math.atan2(
        position.dy - currentBoss.position.dy,
        position.dx - currentBoss.position.dx,
      );
      for (int i = 0; i < count; i++) {
        shots.add(
          Shot(
            currentBoss.position,
            _direction(
                  bossPattern == 1
                      ? aimed + (i - 3) * .16
                      : i * math.pi * 2 / count + elapsed * .3,
                ) *
                (bossPattern == 1 ? 130 : 85),
            10,
            4,
            life: 7,
            radius: 5,
          ),
        );
      }
    }
    for (final s in shots) {
      s.life -= dt;
      s.hitCooldown -= dt;
      if (s.kind == 1 && enemies.isNotEmpty) {
        Foe target = enemies.first;
        for (final e in enemies) {
          if (e.maxHp > target.maxHp) target = e;
        }
        s.velocity = Offset.lerp(
          s.velocity,
          _unit(target.position - s.position) * 275,
          math.min(1, dt * 7),
        )!;
      }
      s.position += s.velocity * dt;
      if (s.kind == 4) {
        if ((position - s.position).distance < 15 && _hurt <= 0) {
          _damage(s.damage);
          s.life = 0;
        }
      } else {
        if (s.kind == 5 && s.hitCooldown > 0) continue;
        bool areaHit = false;
        for (final e in enemies) {
          if (e.hp <= 0) continue;
          if ((e.position - s.position).distance < e.radius + s.radius) {
            e.hp -= s.damage;
            if (s.kind == 1 || s.kind == 3) {
              final blast = (s.kind == 1 ? 44.0 : 55.0) * areaFactor;
              for (final other in enemies) {
                if (other != e &&
                    (other.position - s.position).distance < blast) {
                  other.hp -= s.damage * .7;
                }
              }
              _burst(s.position, 1, 9);
            }
            if (s.kind == 5) {
              areaHit = true;
            } else {
              s.life = 0;
              break;
            }
          }
        }
        if (areaHit) s.hitCooldown = .4;
      }
    }
    shots.removeWhere(
      (s) => s.life <= 0 || (s.position - position).distance > 1000,
    );
    for (final e in enemies.where((e) => e.hp <= 0)) {
      kills++;
      _burst(e.position, e.kind == 3 ? 2 : 0, e.kind == 3 ? 30 : 6);
      for (
        int i = 0;
        i <
            (e.kind == 3
                ? 20
                : e.kind == 2
                ? 4
                : 1);
        i++
      ) {
        crystals.add(
          e.position +
              Offset(
                random.nextDouble() * 20 - 10,
                random.nextDouble() * 20 - 10,
              ),
        );
      }
      if (e.kind == 3) {
        bossesDefeated++;
        supplies.add(Supply(e.position, 3));
        _bossDefeated = bossesDefeated >= requiredBosses;
      }
    }
    enemies.removeWhere((e) => e.hp <= 0);
    final reach = collectionRadius;
    for (int i = crystals.length - 1; i >= 0; i--) {
      final dist = (crystals[i] - position).distance;
      if (dist < reach) {
        crystals[i] += _unit(position - crystals[i]) * 260 * dt;
      }
      if ((crystals[i] - position).distance < 18) {
        crystals.removeAt(i);
        xp += 2 * (1 + (passives['xp'] ?? 0) * .08);
      }
    }
    _checkLevel();
    if (stageIndex > 0 && hazardActive && _hurt <= 0) {
      final danger = stageIndex == 1
          ? (position.dx - (camera.dx + hazardX)).abs() < 27
          : ((position - (camera + const Offset(210, 360))).distance - 145)
                    .abs() <
                19;
      if (danger) _damage(7);
    }
    for (final p in sparks) {
      p.position += p.velocity * dt;
      p.life -= dt;
    }
    sparks.removeWhere((p) => p.life <= 0);
    if (elapsed >= duration && _bossDefeated && !finished) {
      finished = true;
      victory = true;
      _event('victory');
    }
  }

  bool _bossDefeated = false;
  void _checkLevel() {
    if (xp >= xpNeeded && !finished && choices.isEmpty) {
      xp -= xpNeeded;
      level++;
      xpNeeded = 12 + level * 8 + math.max(0, level - 20) * level * .8;
      _offerChoices();
      _event('level');
    }
  }

  void _damage(double amount) {
    hp = math.max(0, hp - amount);
    _hurt = .7;
    _event('hit');
    if (hp <= 0) {
      finished = true;
      victory = false;
      _event('defeat');
    }
  }

  void _burst(Offset at, int kind, int count) {
    for (int i = 0; i < count; i++) {
      if (sparks.length > 160) break;
      sparks.add(
        Spark(
          at,
          _direction(random.nextDouble() * math.pi * 2) *
              (30 + random.nextDouble() * 70),
          .3 + random.nextDouble() * .5,
          kind,
        ),
      );
    }
  }

  Offset _spawnPosition() {
    final edge = random.nextInt(4);
    return camera +
        switch (edge) {
          0 => Offset(random.nextDouble() * 420, -30),
          1 => Offset(450, random.nextDouble() * 720),
          2 => Offset(random.nextDouble() * 420, 750),
          _ => Offset(-30, random.nextDouble() * 720),
        };
  }

  void _spawnEnemy() {
    final at = _spawnPosition();
    final roll = random.nextDouble();
    final kind = elapsed > duration * .3 && roll < .14
        ? 2
        : roll < .45
        ? 1
        : 0;
    enemies.add(
      Foe(
        at,
        kind == 2
            ? 45 + wave * 3.0
            : kind == 1
            ? 10 + wave * 1.0
            : 12 + wave * 1.2,
        kind == 2
            ? 60
            : kind == 1
            ? 105
            : 75,
        kind == 2 ? 19 : 11,
        kind,
      ),
    );
  }

  Foe? _nearest({bool front = false}) {
    Foe? result;
    double distance = double.infinity;
    for (final e in enemies) {
      final v = e.position - position;
      if (front &&
          (_unit(v).dx * math.cos(angle) + _unit(v).dy * math.sin(angle)) <
              .15) {
        continue;
      }
      if (v.distance < distance) {
        distance = v.distance;
        result = e;
      }
    }
    return result;
  }

  void _weapons(double dt) {
    _gun -= dt;
    _missile -= dt;
    _drone -= dt;
    _side -= dt;
    _mine -= dt;
    _trail -= dt;
    final gun = upgrades['gun'] ?? 1;
    if (_gun <= 0) {
      _gun = math.max(.12, .36 - gun * .025) * cooldownFactor;
      final target = _nearest();
      final direction = target == null
          ? _direction(angle)
          : _unit(target.position - position);
      shots.add(
        Shot(
          position + direction * 17,
          direction * 420,
          (13 + gun * 4) * damageFactor,
          0,
        ),
      );
      if (evolved.contains('gun')) {
        for (final turn in [-.13, .13]) {
          shots.add(
            Shot(
              position,
              _direction(math.atan2(direction.dy, direction.dx) + turn) * 420,
              18 * damageFactor,
              0,
            ),
          );
        }
      }
      if (target != null) _event('shoot');
    }
    final missile = upgrades['missile'] ?? 0;
    if (missile > 0 && _missile <= 0 && enemies.isNotEmpty) {
      _missile = math.max(.7, 2.0 - missile * .18) * cooldownFactor;
      for (
        int i = 0;
        i < (evolved.contains('missile') ? 4 : 1 + missile ~/ 3);
        i++
      ) {
        shots.add(
          Shot(
            position,
            _direction(angle + i * 2) * 160,
            (23 + missile * 9) * damageFactor,
            1,
            life: 4,
            radius: 6,
          ),
        );
      }
    }
    final drone = upgrades['drone'] ?? 0;
    if (drone > 0 && _drone <= 0) {
      _drone =
          math.max(.12, .75 - drone * .08) *
          cooldownFactor *
          (evolved.contains('drone') ? .45 : 1);
      final target = _nearest();
      if (target != null &&
          (target.position - position).distance < 210 + drone * 18) {
        final origin = position + _direction(elapsed * 2) * 34;
        shots.add(
          Shot(
            origin,
            _unit(target.position - origin) * 360,
            (12 + drone * 5) * damageFactor,
            2,
          ),
        );
      }
    }
    final side = upgrades['side'] ?? 0;
    if (side > 0 && _side <= 0) {
      _side = (.9 - side * .1) * cooldownFactor;
      for (
        int ray = 0;
        ray < (evolved.contains('side') ? 12 : 4 + side);
        ray++
      ) {
        shots.add(
          Shot(
            position,
            _direction(
                  ray *
                      math.pi *
                      2 /
                      (evolved.contains('side') ? 12 : 4 + side),
                ) *
                330,
            (22 + side * 10) * damageFactor,
            2,
            radius: 6,
          ),
        );
      }
    }
    final mine = upgrades['mine'] ?? 0;
    if (mine > 0 && _mine <= 0) {
      _mine = (evolved.contains('mine') ? .65 : 1.7) * cooldownFactor;
      shots.add(
        Shot(
          position - _direction(angle) * 24,
          Offset.zero,
          (50 + mine * 20) * damageFactor,
          3,
          life: 6 * durationFactor,
          radius: 20 * areaFactor,
        ),
      );
    }
    final trail = upgrades['trail'] ?? 0;
    if (trail > 0 && _trail <= 0) {
      _trail = .45 * cooldownFactor;
      shots.add(
        Shot(
          position - _direction(angle) * 20,
          Offset.zero,
          (14 + trail * 8) * damageFactor,
          5,
          life: 1.8 * durationFactor,
          radius: (evolved.contains('trail') ? 65 : 28) * areaFactor,
        ),
      );
    }
    _guardian -= dt;
    final guardian = upgrades['guardian'] ?? 0;
    if (guardian > 0 && _guardian <= 0) {
      _guardian = .16;
      final reach = (evolved.contains('guardian') ? 95 : 62) * areaFactor;
      for (final e in enemies) {
        if ((e.position - position).distance < reach + e.radius) {
          e.hp -= (5 + guardian * 3) * damageFactor;
          if (e.kind != 3) e.position += _unit(e.position - position) * 9;
        }
      }
      if (guardian >= 3) {
        shots.removeWhere(
          (s) => s.kind == 4 && (s.position - position).distance < reach,
        );
      }
    }
    _lightning -= dt;
    final lightning = upgrades['lightning'] ?? 0;
    if (lightning > 0 && _lightning <= 0 && enemies.isNotEmpty) {
      _lightning = 2 * cooldownFactor;
      for (
        int i = 0;
        i < (evolved.contains('lightning') ? 12 : lightning + 1);
        i++
      ) {
        final e = enemies[random.nextInt(enemies.length)];
        e.hp -= (28 + lightning * 9) * damageFactor;
        _burst(e.position, 1, 5);
      }
    }
  }

  static final catalog = [
    for (final s in survivalSkills)
      UpgradeChoice(s.id, s.name, s.description, s.id),
    const UpgradeChoice('repair', '응급 나노 수리', '최대 선체의 30% 회복', 'repair'),
  ];
  bool canEvolve(String id) =>
      (upgrades[id] ?? 0) == 5 &&
      !evolved.contains(id) &&
      (passives[skillFor(id).partner] ?? 0) > 0;
  void _offerChoices() {
    final pool = <UpgradeChoice>[];
    for (final s in survivalSkills) {
      final current = (s.passive ? passives : upgrades)[s.id] ?? 0;
      if (!s.passive && canEvolve(s.id)) {
        pool.add(
          UpgradeChoice(
            s.id,
            s.evolution!,
            'EVO · ${s.name} + ${skillFor(s.partner!).name}',
            s.id,
            evolution: true,
          ),
        );
      } else if (current < 5 &&
          (current > 0 ||
              (s.passive ? passives.length < 6 : weaponCount < 6))) {
        pool.add(
          UpgradeChoice(
            s.id,
            s.name,
            '${s.passive ? '보조' : '무기'} Lv.$current → ${current + 1} · ${s.description}',
            s.id,
          ),
        );
      }
    }
    pool.shuffle(random);
    choices = pool.take(3).toList();
    if (choices.length < 3) choices.add(catalog.last);
    input = Offset.zero;
  }

  void chooseUpgrade(String id) {
    if (finished || !choices.any((c) => c.id == id)) return;
    final choice = choices.firstWhere((c) => c.id == id);
    if (id == 'repair') {
      hp = math.min(maxHp, hp + maxHp * .3);
    } else if (choice.evolution) {
      evolved.add(id);
    } else if (skillFor(id).passive) {
      passives[id] = (passives[id] ?? 0) + 1;
      if (id == 'hull') {
        maxHp += ship.health * .2;
        hp = math.min(maxHp, hp + ship.health * .2);
      }
    } else {
      upgrades[id] = (upgrades[id] ?? 0) + 1;
    }
    choices = [];
    _checkLevel();
  }

  void _updateSupplies(double dt) {
    _supplyClock -= dt;
    if (_supplyClock <= 0 && supplies.length < 12) {
      _supplyClock = 22;
      supplies.add(
        Supply(
          position +
              Offset(
                random.nextDouble() * 300 - 150,
                random.nextDouble() * 400 - 200,
              ),
          random.nextInt(3),
        ),
      );
    }
    for (int i = supplies.length - 1; i >= 0; i--) {
      final item = supplies[i];
      if ((item.position - position).distance > 28) continue;
      supplies.removeAt(i);
      noticeTime = 2.5;
      switch (item.kind) {
        case 0:
          hp = math.min(maxHp, hp + maxHp * .3);
          pickupNotice = '선체 30% 회복';
        case 1:
          xp += crystals.length * 2 * (1 + (passives['xp'] ?? 0) * .08);
          crystals.clear();
          pickupNotice = '자석 · 전장 경험치 회수';
        case 2:
          for (final e in enemies) {
            e.hp -= e.kind == 3 ? 150 : 9999;
          }
          pickupNotice = '충격파 · 군집 소탕';
        case 3:
          chests++;
          final ready = upgrades.keys.where(canEvolve).toList();
          if (ready.isNotEmpty) {
            evolved.add(ready.first);
            pickupNotice = '보스 보급 · ${skillFor(ready.first).evolution}';
          } else {
            final available = upgrades.keys
                .where((id) => upgrades[id]! < 5)
                .toList();
            if (available.isNotEmpty) {
              final id = available[random.nextInt(available.length)];
              upgrades[id] = upgrades[id]! + 1;
              pickupNotice = '보스 보급 · ${skillFor(id).name} 강화';
            } else {
              hp = math.min(maxHp, hp + maxHp * .3);
              pickupNotice = '보스 보급 · 선체 회복';
            }
          }
          _event('level');
      }
    }
    // Keep abandoned crystals bounded by consolidating distant experience.
    if (crystals.length > 1400) {
      final overflow = crystals.length - 1400;
      crystals.removeRange(0, overflow);
      xp += overflow * 2;
    }
  }
}
