import 'package:flutter/material.dart';

import '../data/content.dart';
import '../data/profile.dart';
import '../game/survival_skills.dart';
import '../main.dart';
import 'components.dart';

class SurvivalMeta extends StatelessWidget {
  const SurvivalMeta({
    super.key,
    required this.profile,
    required this.section,
    required this.onChallenge,
  });
  final Profile profile;
  final int section;
  final void Function(int) onChallenge;
  static const rankColors = [
    Colors.grey,
    Colors.greenAccent,
    Colors.lightBlueAccent,
    Colors.purpleAccent,
    Colors.amber,
  ];
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    padding: const EdgeInsets.all(20),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          ['', '', '장비 공방', '도전과 임무', '진화 도감'][section],
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        gap(8),
        if (section == 2) ...[
          Text(
            '설계도 ${profile.blueprints} · 화력 +${(profile.gearDamage * 100).round()}% · 선체 +${(profile.gearHull * 100).round()}%',
            style: const TextStyle(color: cyan),
          ),
          gap(8),
          const Text(
            '30초·10격파 이상 출격에서 부품과 설계도를 회수합니다. 동일 슬롯 부품으로 등급을 올리고 설계도로 강화하세요.',
            style: TextStyle(color: muted, fontSize: 12),
          ),
          gap(),
          Center(
            child: Image.asset(ships[profile.selectedShip].asset, height: 150),
          ),
          gap(),
          LayoutBuilder(
            builder: (context, c) => Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                for (int i = 0; i < 6; i++)
                  SizedBox(
                    width: (c.maxWidth - 12) / 2,
                    child: Surface(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            Profile.rankNames[profile.gearRanks[i]],
                            style: TextStyle(
                              color: rankColors[profile.gearRanks[i]],
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          gap(8),
                          Text(
                            Profile.gearNames[i],
                            style: const TextStyle(
                              fontSize: 17,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Lv.${profile.gearLevels[i]} / 20',
                            style: const TextStyle(color: muted),
                          ),
                          gap(8),
                          Text(
                            '부품 ${profile.gearCopies[i]} / ${2 * (1 << profile.gearRanks[i])}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          gap(8),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton(
                              onPressed:
                                  profile.gearLevels[i] < 20 &&
                                      profile.blueprints > 0 &&
                                      profile.credits >=
                                          30 + profile.gearLevels[i] * 20
                                  ? () => profile.enhanceGear(i)
                                  : null,
                              child: Text(
                                '강화 ${30 + profile.gearLevels[i] * 20} C',
                                style: const TextStyle(fontSize: 11),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: double.infinity,
                            child: TextButton(
                              onPressed:
                                  profile.gearRanks[i] < 4 &&
                                      profile.gearCopies[i] >=
                                          2 * (1 << profile.gearRanks[i])
                                  ? () => profile.mergeGear(i)
                                  : null,
                              child: const Text('부품 합성'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
        if (section == 3) ...[
          const Text(
            '군집 밀도 증가 · 보스 체력 +40%\n챕터 클리어 후 도전 개방 · 첫 승리 설계도 +5',
            style: TextStyle(color: muted),
          ),
          gap(),
          for (int i = 0; i < stages.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Surface(
                child: Row(
                  children: [
                    Image.asset(
                      'assets/art/survival_boss.png',
                      width: 48,
                      height: 48,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        '${stages[i].name}\n${profile.clearedChallenges.contains(i) ? '도전 완료' : '군집 돌파 도전'}',
                      ),
                    ),
                    TextButton(
                      onPressed: profile.clearedStages.contains(i)
                          ? () => onChallenge(i)
                          : null,
                      child: Text(
                        profile.clearedStages.contains(i) ? '도전' : '잠김',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          gap(),
          const Text(
            '성장 임무',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          gap(),
          for (int i = 0; i < 4; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      Profile.missionNames[i],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '${profile.missionProgress(i)} / ${Profile.missionTargets[i]} · 100 C + 설계도 3',
                      style: const TextStyle(fontSize: 12, color: muted),
                    ),
                    TextButton(
                      onPressed:
                          !profile.claimedMissions.contains(i) &&
                              profile.missionProgress(i) >=
                                  Profile.missionTargets[i]
                          ? () => profile.claimMission(i)
                          : null,
                      child: Text(
                        profile.claimedMissions.contains(i) ? '수령 완료' : '보상 수령',
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
        if (section == 4) ...[
          const Text(
            '무기 6종 + 보조 6종까지 선택\n무기 ★★★★★ + 대응 보조 ★ 이상 → EVO\n레벨업 선택 또는 보스 보급으로 진화',
            style: TextStyle(color: muted),
          ),
          gap(),
          for (final skill in survivalSkills.where((s) => !s.passive))
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Surface(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      skill.name,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      skill.description,
                      style: const TextStyle(color: muted, fontSize: 12),
                    ),
                    gap(8),
                    Text(
                      '★★★★★ + ${skillFor(skill.partner!).name}',
                      style: const TextStyle(color: cyan),
                    ),
                    Text(
                      'EVO  ${skill.evolution}',
                      style: const TextStyle(
                        color: Colors.amber,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ],
    ),
  );
}
