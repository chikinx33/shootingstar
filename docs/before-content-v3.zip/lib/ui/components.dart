import 'package:flutter/material.dart';

import '../main.dart';

class Eyebrow extends StatelessWidget {
  const Eyebrow(this.text, {super.key, this.color = cyan});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Text(
    text,
    style: TextStyle(
      color: color,
      letterSpacing: 2.3,
      fontWeight: FontWeight.w800,
      fontSize: 10,
    ),
  );
}

class Surface extends StatelessWidget {
  const Surface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.active = false,
  });
  final Widget child;
  final EdgeInsetsGeometry padding;
  final bool active;
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: panel.withValues(alpha: .92),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: active ? cyan : const Color(0xFF26374C)),
    ),
    child: child,
  );
}

class Stat extends StatelessWidget {
  const Stat(this.value, this.label, {super.key});
  final String value, label;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        value,
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
      ),
      const SizedBox(height: 3),
      Text(label, style: const TextStyle(fontSize: 11, color: muted)),
    ],
  );
}

Widget gap([double height = 16]) => SizedBox(height: height);
Future<void> showGuide(BuildContext context, VoidCallback done) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      title: const Text('항로에 오신 것을 환영합니다'),
      content: const SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '01  이동만 하세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text('화면을 누르고 드래그하거나 WASD·방향키로 비행합니다. 기체는 이동 방향으로 회전합니다.'),
              SizedBox(height: 16),
              Text(
                '02  모든 방향을 방어합니다',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text('주포 하나로 출발합니다. 사방에서 몰려오는 적을 피하고 경험치를 회수해 최대 6종 무기를 완성하세요.'),
              SizedBox(height: 16),
              Text(
                '03  수집하고 진화하세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text(
                '청록색 경험치를 모으면 3가지 성장 중 하나를 고릅니다. 무기 5단계와 대응 보조 스킬을 갖추면 EVO 진화가 열립니다. 보조 스킬도 최대 6종만 장착할 수 있습니다.',
              ),
              SizedBox(height: 16),
              Text(
                '04  잔광을 남기세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text(
                '중간 보스의 보급 상자와 회복·자석·폭탄을 수집하고 마지막 보스를 격파하세요. 실패해도 크레딧을 받아 격납고에서 영구 성장합니다. Esc·P로 일시정지합니다.',
              ),
            ],
          ),
        ),
      ),
      actions: [
        FilledButton(
          onPressed: () {
            done();
            Navigator.pop(context);
          },
          child: const Text('비행 준비 완료'),
        ),
      ],
    ),
  );
}
