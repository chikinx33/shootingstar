"""Double-click launcher. Standard library only; always binds to loopback."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import socket
import urllib.error
import urllib.request
import webbrowser

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'build' / 'web'

class GameHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def log_message(self, *_args):
        pass

class LocalServer(ThreadingHTTPServer):
    allow_reuse_address = False
    allow_reuse_port = False

    def server_bind(self):
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()

def main():
    parser = argparse.ArgumentParser(description='Open Shootingstar on this computer only.')
    parser.add_argument('--port', type=int, default=8787)
    parser.add_argument('--no-browser', action='store_true', help='For local verification.')
    args = parser.parse_args()
    if not 1 <= args.port <= 65526:
        parser.error('port must be between 1 and 65526')
    if not (WEB / 'main.dart.js').is_file():
        print('Web build is missing. Run tools\\run.ps1 build-web first.', flush=True)
        return 1
    handler = partial(GameHandler, directory=str(WEB))
    server = None
    for port in range(args.port, args.port + 10):
        url = f'http://127.0.0.1:{port}'
        try:
            server = LocalServer(('127.0.0.1', port), handler)
            break
        except OSError:
            try:
                with urllib.request.urlopen(url + '/version.json', timeout=1) as response:
                    ours = json.load(response).get('app_name') == 'shootingstar'
                if ours:
                    print(f'Shootingstar is already running: {url}', flush=True)
                    if not args.no_browser:
                        webbrowser.open(url)
                    return 0
            except (OSError, ValueError, urllib.error.URLError):
                pass
    if server is None:
        print('Could not find a free local port. Close an older game window and try again.', flush=True)
        return 1
    print(f'Shootingstar: {url}', flush=True)
    print('Only this computer can connect. Keep this window open while playing.', flush=True)
    print('Close this window or press Ctrl+C to stop.', flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
