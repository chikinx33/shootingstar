import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shootingstar/main.dart';
import 'package:shootingstar/data/profile.dart';
import 'package:shootingstar/game/battle_painter.dart';
import 'package:shootingstar/ui/battle.dart';

void main() {
  Future<Profile> setup(WidgetTester tester, Size size) async {
    tester.view.physicalSize = size;
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final p = await Profile.load();
    p.updateSettings(soundEnabled: false);
    await tester.pumpWidget(ShootingstarApp(profile: p));
    await tester.pumpAndSettle();
    return p;
  }

  testWidgets('mobile menus, onboarding and settings are readable at 360px', (
    tester,
  ) async {
    final p = await setup(tester, const Size(360, 800));
    expect(find.text('SHOOTINGSTAR'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.byTooltip('설정'));
    await tester.pumpAndSettle();
    expect(find.text('비행 설정'), findsOneWidget);
    await tester.tap(find.text('완료'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('격납고'));
    await tester.pumpAndSettle();
    expect(find.text('당신만의 비행을 설계하세요'), findsOneWidget);
    expect(find.text('115%'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    p.dispose();
  });
  testWidgets('launch pause resume return rewards once and retry cleanly', (
    tester,
  ) async {
    final p = await setup(tester, const Size(1100, 900));
    await tester.tap(find.byKey(const Key('launch')));
    await tester.pumpAndSettle();
    expect(find.text('항로에 오신 것을 환영합니다'), findsOneWidget);
    await tester.tap(find.text('비행 준비 완료'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
    expect(p.onboarded, isTrue);
    expect(find.byType(BattleScreen), findsOneWidget);
    final painter = tester
        .widgetList<CustomPaint>(find.byType(CustomPaint))
        .map((w) => w.painter)
        .whereType<BattlePainter>()
        .first;
    await tester.sendKeyDownEvent(LogicalKeyboardKey.keyD);
    await tester.pump(const Duration(milliseconds: 32));
    expect(painter.game.input.dx, greaterThan(0));
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    await tester.pump();
    expect(painter.game.paused, isTrue);
    expect(painter.game.input, Offset.zero);
    tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await tester.sendKeyUpEvent(LogicalKeyboardKey.keyD);
    await tester.tap(find.text('계속 비행'));
    await tester.pump();
    expect(painter.game.input, Offset.zero);
    await tester.tap(find.byTooltip('일시정지'));
    await tester.pump();
    expect(find.text('궤도 대기'), findsOneWidget);
    await tester.tap(find.text('계속 비행'));
    await tester.pump();
    expect(find.text('궤도 대기'), findsNothing);
    await tester.tap(find.byTooltip('일시정지'));
    await tester.pump();
    await tester.tap(find.text('귀환 · 현재 보상 정산'));
    await tester.pump();
    await tester.pump();
    expect(find.text('다음 궤적을 향해'), findsOneWidget);
    final rewarded = p.credits;
    expect(rewarded, greaterThan(150));
    for (var i = 0; i < 20; i++) {
      await tester.pump(const Duration(milliseconds: 16));
    }
    expect(p.credits, rewarded);
    expect(p.runs, 1);
    await tester.tap(find.text('다시 출격'));
    await tester.pump();
    expect(find.text('다음 궤적을 향해'), findsNothing);
    tester.view.physicalSize = const Size(360, 780);
    await tester.pump();
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
    p.dispose();
    expect(tester.takeException(), isNull);
  });
}
