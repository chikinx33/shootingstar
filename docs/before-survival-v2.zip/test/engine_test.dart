import 'package:flutter_test/flutter_test.dart';

import 'dart:math' as math;

import 'package:shootingstar/game/engine.dart';

GameEngine makeGame({int stage = 0}) => GameEngine(
  stageIndex: stage,
  shipIndex: 0,
  attackLevel: 0,
  hullLevel: 0,
  magnetLevel: 0,
  equipmentIndex: 0,
  seed: 8,
);
void main() {
  test('meta effects match hangar descriptions', () {
    final baseline = makeGame();
    final upgraded = GameEngine(
      stageIndex: 0,
      shipIndex: 0,
      attackLevel: 2,
      hullLevel: 2,
      magnetLevel: 2,
      equipmentIndex: 0,
    );
    expect(upgraded.damageFactor / baseline.damageFactor, closeTo(1.16, .0001));
    expect(upgraded.maxHp / baseline.maxHp, closeTo(1.24, .0001));
    expect(
      upgraded.collectionRadius / baseline.collectionRadius,
      closeTo(1.30, .0001),
    );
  });
  test('pause and upgrade choice freeze complete combat state', () {
    final game = makeGame(stage: 1)..elapsed = 12;
    game.position = Offset(game.hazardX, 360);
    game.enemies.add(Foe(game.position, 500, 40, 30, 3));
    game.shots.add(Shot(game.position, const Offset(0, 50), 10, 4));
    game.sparks.add(Spark(game.position, const Offset(10, 0), 1, 0));
    game.crystals.add(game.position + const Offset(20, 0));
    void expectFrozen() {
      final elapsed = game.elapsed, hp = game.hp;
      final foePosition = game.enemies.first.position;
      final shotLife = game.shots.first.life;
      final sparkLife = game.sparks.first.life;
      final crystal = game.crystals.first;
      final count = game.enemies.length;
      for (int i = 0; i < 200; i++) {
        game.update(.05);
      }
      expect(game.elapsed, elapsed);
      expect(game.hp, hp);
      expect(game.enemies.first.position, foePosition);
      expect(game.shots.first.life, shotLife);
      expect(game.sparks.first.life, sparkLife);
      expect(game.crystals.first, crystal);
      expect(game.enemies.length, count);
    }

    game.setPaused(true);
    expectFrozen();
    game.setPaused(false);
    game.choices = [GameEngine.catalog.first];
    expectFrozen();
  });
  test(
    'large experience grants queue choices without advancing simulation',
    () {
      final game = makeGame()..xp = 100;
      game.update(.05);
      final elapsed = game.elapsed;
      int selections = 0;
      while (game.choices.isNotEmpty) {
        expect(game.choices.length, 3);
        game.chooseUpgrade(game.choices.first.id);
        selections++;
        expect(game.elapsed, elapsed);
        expect(selections, lessThan(15));
      }
      expect(selections, greaterThan(3));
      expect(game.xp, lessThan(game.xpNeeded));
    },
  );
  test('simultaneous player and boss death always awards defeat', () {
    for (int stage = 0; stage < 3; stage++) {
      final game = makeGame(stage: stage)..elapsed = 220;
      game.update(.01);
      game.enemies.removeWhere((e) => e.kind != 3);
      game.boss!.position = game.position;
      game.boss!.hp = 1;
      game.hp = 1;
      game.shots.add(Shot(game.position, Offset.zero, 100, 0));
      game.update(.01);
      expect(game.finished, isTrue);
      expect(game.victory, isFalse);
      expect(game.hp, 0);
      expect(game.boss, isNull);
    }
  });
  test('starter movement smoke across three stages', () {
    for (int stage = 0; stage < 3; stage++) {
      int wins = 0;
      final summaries = <String>[];
      for (int seed = 0; seed < 3; seed++) {
        final game = GameEngine(
          stageIndex: stage,
          shipIndex: 0,
          attackLevel: 0,
          hullLevel: 0,
          magnetLevel: 0,
          equipmentIndex: 0,
          seed: seed,
        );
        for (int frame = 0; frame < 7000 && !game.finished; frame++) {
          if (game.choices.isNotEmpty) {
            final choices = [...game.choices];
            choices.sort((a, b) {
              int score(UpgradeChoice c) =>
                  c.id == 'repair' && game.hp < game.maxHp * .65
                  ? 100
                  : c.evolution
                  ? 90
                  : {
                          'gun': 70,
                          'missile': 65,
                          'drone': 60,
                          'magnet': 45,
                          'side': 40,
                          'mine': 30,
                          'trail': 20,
                        }[c.id] ??
                        0;
              return score(b).compareTo(score(a));
            });
            game.chooseUpgrade(choices.first.id);
          }
          final orbit = Offset(
            210 + 130 * math.cos(game.elapsed * .65),
            360 + 225 * math.sin(game.elapsed * .65),
          );
          var target = orbit;
          double nearest = 130;
          for (final crystal in game.crystals) {
            final distance = (crystal - game.position).distance;
            if (distance < nearest) {
              nearest = distance;
              target = crystal;
            }
          }
          var steer = target - game.position;
          if (steer.distance > 1) steer /= steer.distance;
          for (final enemy in game.enemies) {
            final away = game.position - enemy.position;
            if (away.distance < 65 && away.distance > .01) {
              steer += away / away.distance * (65 - away.distance) / 18;
            }
          }
          game.input = steer;
          game.update(.05);
        }
        if (game.victory) wins++;
        summaries.add(
          'seed=$seed won=${game.victory} t=${game.elapsed.toStringAsFixed(1)} hp=${game.hp.toStringAsFixed(0)} level=${game.level} kills=${game.kills}',
        );
      }
      // Evidence, not a human-play certification; no HP or combat cheats used.
      // ignore: avoid_print
      print('STARTER stage=$stage wins=$wins/3 ${summaries.join('; ')}');
      expect(
        wins,
        greaterThan(0),
        reason: 'A moving starter must have a viable path through stage $stage',
      );
    }
  });
  test('pause, invalid delta and level choice freeze time', () {
    final game = makeGame();
    game.setPaused(true);
    game.update(.05);
    expect(game.elapsed, 0);
    game.setPaused(false);
    game.update(double.nan);
    expect(game.elapsed, 0);
    game.xp = game.xpNeeded;
    game.update(.05);
    expect(game.choices.length, 3);
    final time = game.elapsed;
    game.update(.05);
    expect(game.elapsed, time);
    game.chooseUpgrade('unknown');
    expect(game.choices.length, 3);
    game.chooseUpgrade(game.choices.first.id);
    expect(game.choices, isEmpty);
    game.update(.05);
    expect(game.elapsed, greaterThan(time));
  });
  test('movement remains in arena and rotates smoothly', () {
    final game = makeGame()..input = const Offset(100, 100);
    for (int i = 0; i < 300; i++) {
      game.update(.05);
    }
    expect(game.position.dx, inInclusiveRange(18, 402));
    expect(game.position.dy, inInclusiveRange(24, 696));
    expect(game.angle.isFinite, isTrue);
  });
  test('starting escort protects rear and projectiles expire', () {
    final game = makeGame();
    game.enemies.add(Foe(const Offset(210, 450), 20, 0, 12, 0));
    for (int i = 0; i < 45; i++) {
      game.update(.05);
    }
    expect(game.kills, greaterThan(0));
    expect(game.shots.length, lessThan(50));
  });
  test('boss defeat and survival finish with victory exactly once', () {
    final game = makeGame();
    int wins = 0;
    game.onEvent = (event) {
      if (event == 'victory') wins++;
    };
    game.elapsed = game.duration - 1;
    game.update(.05);
    expect(game.boss, isNotNull);
    game.boss!.hp = 0;
    game.update(.05);
    game.elapsed = game.duration;
    game.update(.05);
    expect(game.victory, isTrue);
    expect(game.finished, isTrue);
    game.update(.05);
    expect(wins, 1);
  });
  test('contact damage causes defeat, abandon is terminal', () {
    final game = makeGame()..hp = 1;
    game.enemies.add(Foe(game.position, 999, 0, 20, 2));
    game.update(.05);
    expect(game.finished, isTrue);
    expect(game.victory, isFalse);
    final another = makeGame()..abandon();
    another.update(.05);
    expect(another.elapsed, 0);
  });
  test('all stage timelines and evolved weapons stay bounded', () {
    for (int stage = 0; stage < 3; stage++) {
      final game = makeGame(stage: stage);
      game.upgrades.addAll({
        'gun': 4,
        'missile': 4,
        'drone': 4,
        'side': 4,
        'mine': 4,
        'trail': 4,
      });
      for (int frame = 0; frame < 6000 && !game.finished; frame++) {
        // Isolate resource lifetime and complete timelines from player survival.
        game.hp = game.maxHp;
        if (game.choices.isNotEmpty) game.chooseUpgrade(game.choices.first.id);
        game.input = game.crystals.isEmpty
            ? Offset.zero
            : game.crystals.first - game.position;
        game.update(.05);
        expect(game.enemies.length, lessThanOrEqualTo(66));
        expect(game.shots.length, lessThan(220));
        expect(game.sparks.length, lessThanOrEqualTo(161));
        expect(game.position.dx.isFinite && game.position.dy.isFinite, isTrue);
      }
      expect(
        game.victory,
        isTrue,
        reason: 'stage $stage can finish after boss defeat',
      );
      expect(game.kills, greaterThan(30));
    }
  });
}
