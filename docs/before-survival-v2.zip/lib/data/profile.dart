import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'content.dart';

class Profile extends ChangeNotifier {
  Profile._(this._prefs);
  static const storageKey = 'shootingstar.profile.v1';
  final SharedPreferences? _prefs;
  final Set<String> _processedRunIds = {};
  Future<void> _pendingSave = Future<void>.value();
  bool _disposed = false;
  int credits = 150, selectedShip = 0, selectedStage = 0, equipment = 0;
  int attackLevel = 0, hullLevel = 0, magnetLevel = 0;
  Set<int> unlockedShips = {0}, clearedStages = {};
  bool onboarded = false, reducedEffects = false, soundEnabled = true;
  double volume = .5;
  int runs = 0, bestKills = 0;
  String? saveError;

  static Future<Profile> load({
    @visibleForTesting Future<SharedPreferences> Function()? preferencesLoader,
  }) async {
    SharedPreferences? prefs;
    try {
      prefs = await (preferencesLoader ?? SharedPreferences.getInstance)();
    } catch (_) {
      return Profile._(null)
        ..saveError = '저장소를 사용할 수 없습니다. 이번 진행은 앱을 종료하면 사라집니다.';
    }
    final profile = Profile._(prefs);
    try {
      final raw = prefs.getString(storageKey);
      if (raw != null) {
        final decoded = jsonDecode(raw);
        if (decoded is! Map<String, dynamic>) {
          throw const FormatException('Invalid profile');
        }
        profile._restore(decoded);
      }
    } catch (_) {
      profile.saveError = '저장 데이터를 읽지 못해 기본 상태로 시작합니다.';
    }
    return profile;
  }

  static int _integer(dynamic value, int fallback, int maximum) =>
      value is num && value.isFinite
      ? value.toInt().clamp(0, maximum)
      : fallback;
  void _restore(Map<String, dynamic> data) {
    final processedIds = data['processedRunIds'];
    if (processedIds is List) {
      final validIds = processedIds
          .whereType<String>()
          .where((id) => id.isNotEmpty && id.length <= 200)
          .toSet()
          .toList();
      _processedRunIds.addAll(
        validIds.skip(validIds.length > 100 ? validIds.length - 100 : 0),
      );
    }
    credits = _integer(data['credits'], 150, 9999999);
    attackLevel = _integer(data['attackLevel'], 0, maxUpgradeLevel);
    hullLevel = _integer(data['hullLevel'], 0, maxUpgradeLevel);
    magnetLevel = _integer(data['magnetLevel'], 0, maxUpgradeLevel);
    runs = _integer(data['runs'], 0, 9999999);
    bestKills = _integer(data['bestKills'], 0, 9999999);
    Set<int> validSet(dynamic value, int length) => value is List
        ? value.whereType<int>().where((v) => v >= 0 && v < length).toSet()
        : <int>{};
    unlockedShips = validSet(data['unlockedShips'], ships.length)..add(0);
    clearedStages = validSet(data['clearedStages'], stages.length);
    selectedShip = _integer(data['selectedShip'], 0, ships.length - 1);
    if (!unlockedShips.contains(selectedShip)) selectedShip = 0;
    selectedStage = _integer(data['selectedStage'], 0, stages.length - 1);
    if (!canStage(selectedStage)) selectedStage = 0;
    equipment = _integer(data['equipment'], 0, equipmentOptions.length - 1);
    onboarded = data['onboarded'] == true;
    reducedEffects = data['reducedEffects'] == true;
    soundEnabled = data['soundEnabled'] is bool
        ? data['soundEnabled'] as bool
        : true;
    final savedVolume = data['volume'];
    volume = savedVolume is num && savedVolume.isFinite
        ? savedVolume.toDouble().clamp(0, 1)
        : .5;
  }

  Map<String, dynamic> _snapshot() => {
    'version': 1,
    'credits': credits,
    'selectedShip': selectedShip,
    'selectedStage': selectedStage,
    'equipment': equipment,
    'attackLevel': attackLevel,
    'hullLevel': hullLevel,
    'magnetLevel': magnetLevel,
    'unlockedShips': unlockedShips.toList()..sort(),
    'clearedStages': clearedStages.toList()..sort(),
    'onboarded': onboarded,
    'reducedEffects': reducedEffects,
    'soundEnabled': soundEnabled,
    'volume': volume,
    'runs': runs,
    'bestKills': bestKills,
    'processedRunIds': _processedRunIds.toList(),
  };

  Future<void> save() {
    final encoded = jsonEncode(_snapshot());
    _pendingSave = _pendingSave.then((_) async {
      try {
        if (_prefs == null) {
          saveError = '저장소를 사용할 수 없습니다. 이번 진행은 앱을 종료하면 사라집니다.';
          if (!_disposed) notifyListeners();
          return;
        }
        final success = await _prefs.setString(storageKey, encoded);
        if (!success) throw StateError('Storage rejected write');
        saveError = null;
      } catch (_) {
        saveError = '진행 저장에 실패했습니다. 브라우저 저장 공간을 확인하세요.';
      }
      if (!_disposed) notifyListeners();
    });
    return _pendingSave;
  }

  void _changed() {
    if (!_disposed) notifyListeners();
    save();
  }

  bool canStage(int index) =>
      index >= 0 &&
      index < stages.length &&
      (index == 0 || clearedStages.contains(index - 1));
  bool unlockShip(int index) {
    if (index < 0 ||
        index >= ships.length ||
        unlockedShips.contains(index) ||
        credits < ships[index].unlockCost) {
      return false;
    }
    credits -= ships[index].unlockCost;
    unlockedShips.add(index);
    _changed();
    return true;
  }

  int upgradeLevel(String kind) => switch (kind) {
    'attack' => attackLevel,
    'hull' => hullLevel,
    'magnet' => magnetLevel,
    _ => -1,
  };
  bool buyUpgrade(String kind) {
    final level = upgradeLevel(kind);
    if (level < 0 || level >= maxUpgradeLevel || credits < upgradeCost(level)) {
      return false;
    }
    credits -= upgradeCost(level);
    switch (kind) {
      case 'attack':
        attackLevel++;
      case 'hull':
        hullLevel++;
      case 'magnet':
        magnetLevel++;
    }
    _changed();
    return true;
  }

  void selectShip(int index) {
    if (unlockedShips.contains(index) && index >= 0 && index < ships.length) {
      selectedShip = index;
      _changed();
    }
  }

  void selectStage(int index) {
    if (canStage(index)) {
      selectedStage = index;
      _changed();
    }
  }

  void selectEquipment(int index) {
    if (index >= 0 && index < equipmentOptions.length) {
      equipment = index;
      _changed();
    }
  }

  void finishOnboarding() {
    onboarded = true;
    _changed();
  }

  void updateSettings({
    bool? soundEnabled,
    bool? reducedEffects,
    double? volume,
  }) {
    if (soundEnabled != null) this.soundEnabled = soundEnabled;
    if (reducedEffects != null) this.reducedEffects = reducedEffects;
    if (volume != null && volume.isFinite) this.volume = volume.clamp(0, 1);
    _changed();
  }

  int completeRun({
    required bool victory,
    required int stageIndex,
    required int kills,
    required int level,
    required int seconds,
    required bool training,
    String? runId,
  }) {
    if (training || !canStage(stageIndex)) return 0;
    if (runId != null) {
      if (runId.isEmpty ||
          runId.length > 200 ||
          _processedRunIds.contains(runId)) {
        return 0;
      }
      _processedRunIds.add(runId);
      if (_processedRunIds.length > 100) {
        _processedRunIds.remove(_processedRunIds.first);
      }
    }
    final safeKills = kills.clamp(0, 100000);
    final reward =
        (20 +
                safeKills ~/ 4 +
                level.clamp(1, 100) * 3 +
                seconds.clamp(0, stages[stageIndex].duration) ~/ 6 +
                (victory ? 80 + stageIndex * 20 : 0))
            .clamp(20, 500);
    credits = (credits + reward).clamp(0, 9999999);
    runs++;
    if (safeKills > bestKills) bestKills = safeKills;
    if (victory) clearedStages.add(stageIndex);
    _changed();
    return reward;
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
