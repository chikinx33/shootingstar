import 'dart:math' as math;
import 'dart:ui';

import '../data/content.dart' as content;

class UpgradeChoice {
  final String id, title, description, iconKey;
  final bool evolution;
  const UpgradeChoice(
    this.id,
    this.title,
    this.description,
    this.iconKey, {
    this.evolution = false,
  });
}

class Foe {
  Offset position;
  double hp, maxHp, speed, radius, phase = 0;
  final int kind;
  Foe(this.position, this.hp, this.speed, this.radius, this.kind) : maxHp = hp;
}

class Shot {
  Offset position, velocity;
  double life, damage, radius;
  final int kind;
  Shot(
    this.position,
    this.velocity,
    this.damage,
    this.kind, {
    this.life = 2,
    this.radius = 3,
  });
}

class Spark {
  Offset position, velocity;
  double life;
  final int kind;
  Spark(this.position, this.velocity, this.life, this.kind);
}

class GameEngine {
  final int stageIndex,
      shipIndex,
      attackLevel,
      hullLevel,
      magnetLevel,
      equipmentIndex;
  final bool training;
  final math.Random random;
  void Function(String)? onEvent;
  Offset position = const Offset(210, 380), input = Offset.zero;
  double angle = -math.pi / 2,
      elapsed = 0,
      hp = 100,
      maxHp = 100,
      xp = 0,
      xpNeeded = 10;
  int level = 1, kills = 0;
  bool paused = false, finished = false, victory = false;
  List<UpgradeChoice> choices = [];
  final Map<String, int> upgrades = {'gun': 1, 'missile': 1, 'drone': 1};
  final List<Foe> enemies = [];
  final List<Shot> shots = [];
  final List<Offset> crystals = [];
  final List<Spark> sparks = [];
  double _spawn = 0,
      _gun = 0,
      _missile = 0,
      _drone = 0,
      _side = 0,
      _mine = 0,
      _trail = 0,
      _hurt = 0,
      _audio = 0,
      _bossFire = 0;
  bool _bossSpawned = false;
  GameEngine({
    required this.stageIndex,
    required this.shipIndex,
    required this.attackLevel,
    required this.hullLevel,
    required this.magnetLevel,
    required this.equipmentIndex,
    int? seed,
    this.training = false,
  }) : random = math.Random(seed) {
    maxHp =
        ship.health *
        (1 + hullLevel * .12) *
        (equipmentIndex == 0
            ? 1.2
            : equipmentIndex == 1
            ? .9
            : 1);
    hp = maxHp;
  }
  content.ShipSpec get ship =>
      content.ships[shipIndex.clamp(0, content.ships.length - 1)];
  double get duration => training
      ? 45
      : content.stages[stageIndex.clamp(0, content.stages.length - 1)].duration
            .toDouble();
  double get damageFactor =>
      (1 + attackLevel * .08) * ship.damage * (equipmentIndex == 1 ? 1.2 : 1);
  double get moveSpeed => ship.speed * (equipmentIndex == 2 ? 1.05 : 1);
  double get collectionRadius =>
      (55 * (1 + magnetLevel * .15) + (upgrades['magnet'] ?? 0) * 28) *
      (equipmentIndex == 2 ? 1.7 : 1);
  Foe? get boss {
    for (final e in enemies) {
      if (e.kind == 3) return e;
    }
    return null;
  }

  double get bossHealth => boss == null ? 0 : boss!.hp / boss!.maxHp;
  bool get bossSpawned => _bossSpawned;
  double get hurtFlash => _hurt;
  String get statusText => boss != null
      ? '거대 함선 · 코어를 파괴하세요'
      : stageIndex == 1
      ? '이온 폭풍 · 빛나는 세로 영역 주의'
      : stageIndex == 2
      ? '중력 파동 · 붉은 고리에서 벗어나세요'
      : '성운 외곽 · 적 포위를 돌파하세요';
  double get hazardPhase => elapsed % 14;
  double get hazardX => 70 + ((elapsed ~/ 14) * 113 % 280).toDouble();
  bool get hazardActive => hazardPhase > 11;
  void setPaused(bool value) {
    if (!finished) {
      paused = value;
      input = Offset.zero;
    }
  }

  void abandon() {
    finished = true;
    victory = false;
    input = Offset.zero;
  }

  void _event(String event) {
    if (event != 'shoot' || _audio <= 0) {
      onEvent?.call(event);
      if (event == 'shoot') _audio = .18;
    }
  }

  Offset _unit(Offset v) =>
      v.distance < .001 ? const Offset(0, -1) : v / v.distance;
  Offset _direction(double a) => Offset(math.cos(a), math.sin(a));
  void update(double delta) {
    if (finished ||
        paused ||
        choices.isNotEmpty ||
        !delta.isFinite ||
        delta <= 0) {
      return;
    }
    final dt = delta.clamp(0.0, .05);
    elapsed += dt;
    _audio -= dt;
    _hurt -= dt;
    final movement = input.distance > 1 ? _unit(input) : input;
    position += movement * moveSpeed * dt;
    position = Offset(
      position.dx.clamp(32.0, 388.0),
      position.dy.clamp(32.0, 688.0),
    );
    if (movement.distance > .05) {
      final target = math.atan2(movement.dy, movement.dx);
      final diff = math.atan2(
        math.sin(target - angle),
        math.cos(target - angle),
      );
      angle += diff * math.min(1, dt * 9);
    }
    _spawn -= dt;
    if (_spawn <= 0 && elapsed < duration && enemies.length < 65) {
      _spawn = math.max(.28, 1.0 - elapsed / duration * .55 - stageIndex * .05);
      _spawnEnemy();
    }
    if (!_bossSpawned && elapsed >= duration - (training ? 16 : 32)) {
      _bossSpawned = true;
      enemies.add(
        Foe(
          const Offset(210, -45),
          training ? 170 : 500 + stageIndex * 150,
          23,
          34,
          3,
        ),
      );
      _event('boss');
    }
    _weapons(dt);
    for (final e in enemies) {
      e.phase += dt;
      final toward = _unit(position - e.position);
      e.position += toward * e.speed * dt;
      if (e.kind == 1) {
        e.position +=
            Offset(-toward.dy, toward.dx) * math.sin(e.phase * 5) * 25 * dt;
      }
      if ((e.position - position).distance < e.radius + 12 && _hurt <= 0) {
        _damage(
          e.kind == 3
              ? 20
              : e.kind == 2
              ? 15
              : 9,
        );
        e.position -= toward * 24;
      }
    }
    final currentBoss = boss;
    _bossFire -= dt;
    if (currentBoss != null && _bossFire <= 0) {
      _bossFire = 2.3;
      for (int i = 0; i < 10; i++) {
        shots.add(
          Shot(
            currentBoss.position,
            _direction(i * math.pi / 5 + elapsed * .3) * 85,
            10,
            4,
            life: 7,
            radius: 5,
          ),
        );
      }
    }
    for (final s in shots) {
      s.life -= dt;
      if (s.kind == 1 && enemies.isNotEmpty) {
        Foe target = enemies.first;
        for (final e in enemies) {
          if (e.maxHp > target.maxHp) target = e;
        }
        s.velocity = Offset.lerp(
          s.velocity,
          _unit(target.position - s.position) * 275,
          math.min(1, dt * 7),
        )!;
      }
      s.position += s.velocity * dt;
      if (s.kind == 4) {
        if ((position - s.position).distance < 15 && _hurt <= 0) {
          _damage(s.damage);
          s.life = 0;
        }
      } else {
        for (final e in enemies) {
          if (e.hp <= 0) continue;
          if ((e.position - s.position).distance < e.radius + s.radius) {
            e.hp -= s.damage;
            if (s.kind == 1 || s.kind == 3) {
              final blast = s.kind == 1 ? 44.0 : 55.0;
              for (final other in enemies) {
                if (other != e &&
                    (other.position - s.position).distance < blast) {
                  other.hp -= s.damage * .7;
                }
              }
              _burst(s.position, 1, 9);
            }
            s.life = 0;
            break;
          }
        }
      }
    }
    shots.removeWhere(
      (s) =>
          s.life <= 0 ||
          s.position.dx < -100 ||
          s.position.dx > 520 ||
          s.position.dy < -120 ||
          s.position.dy > 840,
    );
    for (final e in enemies.where((e) => e.hp <= 0)) {
      kills++;
      _burst(e.position, e.kind == 3 ? 2 : 0, e.kind == 3 ? 30 : 6);
      for (
        int i = 0;
        i <
            (e.kind == 3
                ? 20
                : e.kind == 2
                ? 4
                : 1);
        i++
      ) {
        crystals.add(
          e.position +
              Offset(
                random.nextDouble() * 20 - 10,
                random.nextDouble() * 20 - 10,
              ),
        );
      }
      if (e.kind == 3) {
        _bossDefeated = true;
      }
    }
    enemies.removeWhere((e) => e.hp <= 0);
    final reach = collectionRadius;
    for (int i = crystals.length - 1; i >= 0; i--) {
      final dist = (crystals[i] - position).distance;
      if (dist < reach || crystals.length > 100) {
        crystals[i] += _unit(position - crystals[i]) * 260 * dt;
      }
      if ((crystals[i] - position).distance < 18) {
        crystals.removeAt(i);
        xp += 2;
      }
    }
    _checkLevel();
    if (stageIndex > 0 && hazardActive && _hurt <= 0) {
      final danger = stageIndex == 1
          ? (position.dx - hazardX).abs() < 27
          : ((position - const Offset(210, 360)).distance - 145).abs() < 19;
      if (danger) _damage(7);
    }
    for (final p in sparks) {
      p.position += p.velocity * dt;
      p.life -= dt;
    }
    sparks.removeWhere((p) => p.life <= 0);
    if (elapsed >= duration && _bossDefeated && !finished) {
      finished = true;
      victory = true;
      _event('victory');
    }
  }

  bool _bossDefeated = false;
  void _checkLevel() {
    if (xp >= xpNeeded && !finished && choices.isEmpty) {
      xp -= xpNeeded;
      level++;
      xpNeeded = 8 + level * 3;
      _offerChoices();
      _event('level');
    }
  }

  void _damage(double amount) {
    hp = math.max(0, hp - amount);
    _hurt = .7;
    _event('hit');
    if (hp <= 0) {
      finished = true;
      victory = false;
      _event('defeat');
    }
  }

  void _burst(Offset at, int kind, int count) {
    for (int i = 0; i < count; i++) {
      if (sparks.length > 160) break;
      sparks.add(
        Spark(
          at,
          _direction(random.nextDouble() * math.pi * 2) *
              (30 + random.nextDouble() * 70),
          .3 + random.nextDouble() * .5,
          kind,
        ),
      );
    }
  }

  void _spawnEnemy() {
    final edge = random.nextInt(4);
    final at = switch (edge) {
      0 => Offset(random.nextDouble() * 420, -25),
      1 => Offset(445, random.nextDouble() * 720),
      2 => Offset(random.nextDouble() * 420, 745),
      _ => Offset(-25, random.nextDouble() * 720),
    };
    final roll = random.nextDouble();
    final kind = elapsed > duration * .3 && roll < .14
        ? 2
        : roll < .45
        ? 1
        : 0;
    enemies.add(
      Foe(
        at,
        kind == 2
            ? 65
            : kind == 1
            ? 18
            : 25,
        kind == 2
            ? 35
            : kind == 1
            ? 68
            : 46,
        kind == 2 ? 19 : 11,
        kind,
      ),
    );
  }

  Foe? _nearest({bool front = false}) {
    Foe? result;
    double distance = double.infinity;
    for (final e in enemies) {
      final v = e.position - position;
      if (front &&
          (_unit(v).dx * math.cos(angle) + _unit(v).dy * math.sin(angle)) <
              .15) {
        continue;
      }
      if (v.distance < distance) {
        distance = v.distance;
        result = e;
      }
    }
    return result;
  }

  void _weapons(double dt) {
    _gun -= dt;
    _missile -= dt;
    _drone -= dt;
    _side -= dt;
    _mine -= dt;
    _trail -= dt;
    final gun = upgrades['gun'] ?? 1;
    if (_gun <= 0) {
      _gun = math.max(.12, .36 - gun * .025);
      final target = _nearest(front: true);
      final direction = target == null
          ? _direction(angle)
          : _unit(target.position - position);
      shots.add(
        Shot(
          position + direction * 17,
          direction * 420,
          (13 + gun * 4) * damageFactor,
          0,
        ),
      );
      if (gun >= 4) {
        for (final turn in [-.13, .13]) {
          shots.add(
            Shot(
              position,
              _direction(math.atan2(direction.dy, direction.dx) + turn) * 420,
              18 * damageFactor,
              0,
            ),
          );
        }
      }
      if (target != null) _event('shoot');
    }
    final missile = upgrades['missile'] ?? 1;
    if (_missile <= 0 && enemies.isNotEmpty) {
      _missile = math.max(.7, 2.0 - missile * .18);
      for (int i = 0; i < (missile >= 4 ? 3 : 1); i++) {
        shots.add(
          Shot(
            position,
            _direction(angle + i * 2) * 160,
            (23 + missile * 9) * damageFactor,
            1,
            life: 4,
            radius: 6,
          ),
        );
      }
    }
    final drone = upgrades['drone'] ?? 1;
    if (_drone <= 0) {
      _drone = math.max(.2, .75 - drone * .08);
      final target = _nearest();
      if (target != null &&
          (target.position - position).distance < 210 + drone * 18) {
        final origin = position + _direction(elapsed * 2) * 34;
        shots.add(
          Shot(
            origin,
            _unit(target.position - origin) * 360,
            (12 + drone * 5) * damageFactor,
            2,
          ),
        );
      }
    }
    final side = upgrades['side'] ?? 0;
    if (side > 0 && _side <= 0) {
      _side = .9 - side * .1;
      for (final sign in [-1, 1]) {
        shots.add(
          Shot(
            position,
            _direction(angle + sign * math.pi / 2) * 330,
            (22 + side * 10) * damageFactor,
            2,
            radius: 6,
          ),
        );
      }
    }
    final mine = upgrades['mine'] ?? 0;
    if (mine > 0 && _mine <= 0) {
      _mine = 1.7;
      shots.add(
        Shot(
          position - _direction(angle) * 24,
          Offset.zero,
          (50 + mine * 20) * damageFactor,
          3,
          life: 6,
          radius: 20,
        ),
      );
    }
    final trail = upgrades['trail'] ?? 0;
    if (trail > 0 && _trail <= 0 && input.distance > .1) {
      _trail = .35;
      shots.add(
        Shot(
          position - _direction(angle) * 20,
          Offset.zero,
          (14 + trail * 8) * damageFactor,
          5,
          life: 1.8,
          radius: 17,
        ),
      );
    }
  }

  static const catalog = [
    UpgradeChoice('gun', '펄스 주포', '전방 자동 조준 · 공격력과 연사 증가', 'gun'),
    UpgradeChoice('missile', '추적성 미사일', '전방위 강한 적 추적 · 폭발 강화', 'missile'),
    UpgradeChoice('drone', '호위 드론', '가까운 적 요격 · 사거리와 연사 증가', 'drone'),
    UpgradeChoice('side', '측면 광자포', '좌우로 강한 광자 탄환 발사', 'side'),
    UpgradeChoice('mine', '중력 기뢰', '후방에 지속형 폭발 기뢰 배치', 'mine'),
    UpgradeChoice('trail', '플라스마 항적', '이동 경로에 피해를 주는 에너지 생성', 'trail'),
    UpgradeChoice('repair', '응급 나노 수리', '장갑 35% 회복 · 최대 장갑 +10', 'repair'),
    UpgradeChoice('magnet', '회수 자기장', '경험치 수집 반경 증가', 'magnet'),
  ];
  void _offerChoices() {
    final pool =
        catalog
            .where((c) => c.id == 'repair' || (upgrades[c.id] ?? 0) < 5)
            .toList()
          ..shuffle(random);
    choices = pool
        .take(3)
        .map(
          (c) =>
              (upgrades[c.id] ?? 0) == 3 &&
                  ['gun', 'missile', 'drone'].contains(c.id)
              ? UpgradeChoice(
                  c.id,
                  '${c.title} 진화',
                  c.id == 'gun'
                      ? '삼중 광선 · 전방 화망 대폭 확장'
                      : c.id == 'missile'
                      ? '삼중 추적 · 폭발 미사일 군집'
                      : '초고속 요격 · 전방위 보호 강화',
                  c.iconKey,
                  evolution: true,
                )
              : c,
        )
        .toList();
    input = Offset.zero;
  }

  void chooseUpgrade(String id) {
    if (finished || !choices.any((c) => c.id == id)) return;
    if (id == 'repair') {
      maxHp += 10;
      hp = math.min(maxHp, hp + maxHp * .35);
    } else {
      upgrades[id] = (upgrades[id] ?? 0) + 1;
    }
    choices = [];
    _checkLevel();
  }
}
