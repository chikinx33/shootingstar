import 'package:flutter/material.dart';

import '../main.dart';

class Eyebrow extends StatelessWidget {
  const Eyebrow(this.text, {super.key, this.color = cyan});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Text(
    text,
    style: TextStyle(
      color: color,
      letterSpacing: 2.3,
      fontWeight: FontWeight.w800,
      fontSize: 10,
    ),
  );
}

class Surface extends StatelessWidget {
  const Surface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.active = false,
  });
  final Widget child;
  final EdgeInsetsGeometry padding;
  final bool active;
  @override
  Widget build(BuildContext context) => Container(
    padding: padding,
    decoration: BoxDecoration(
      color: panel.withValues(alpha: .92),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: active ? cyan : const Color(0xFF26374C)),
    ),
    child: child,
  );
}

class Stat extends StatelessWidget {
  const Stat(this.value, this.label, {super.key});
  final String value, label;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(
        value,
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
      ),
      const SizedBox(height: 3),
      Text(label, style: const TextStyle(fontSize: 11, color: muted)),
    ],
  );
}

Widget gap([double height = 16]) => SizedBox(height: height);
Future<void> showGuide(BuildContext context, VoidCallback done) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (context) => AlertDialog(
      title: const Text('항로에 오신 것을 환영합니다'),
      content: const SizedBox(
        width: 440,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '01  이동만 하세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text('화면을 누르고 드래그하거나 WASD·방향키로 비행합니다. 기체는 이동 방향으로 회전합니다.'),
              SizedBox(height: 16),
              Text(
                '02  모든 방향을 방어합니다',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text('전방 주포는 자동 조준합니다. 유도 미사일과 호위 드론이 시작부터 뒤쪽 적까지 요격합니다.'),
              SizedBox(height: 16),
              Text(
                '03  수집하고 진화하세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text(
                '청록색 경험치를 모으면 3가지 성장 중 하나를 고릅니다. 주포·미사일·드론을 3단계까지 키우면 강력한 진화를 선택할 수 있습니다.',
              ),
              SizedBox(height: 16),
              Text(
                '04  잔광을 남기세요',
                style: TextStyle(color: cyan, fontWeight: FontWeight.bold),
              ),
              Text(
                '경고 구역을 피하고 마지막 보스를 격파하세요. 실패해도 크레딧을 받아 격납고에서 영구 성장합니다. Esc·P로 일시정지합니다.',
              ),
            ],
          ),
        ),
      ),
      actions: [
        FilledButton(
          onPressed: () {
            done();
            Navigator.pop(context);
          },
          child: const Text('비행 준비 완료'),
        ),
      ],
    ),
  );
}
