import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

import '../data/content.dart';
import '../data/profile.dart';
import '../game/engine.dart';
import '../game/battle_painter.dart';
import '../services/sound.dart';
import '../main.dart';
import 'components.dart';

class BattleScreen extends StatefulWidget {
  const BattleScreen({super.key, required this.profile, this.training = false});
  final Profile profile;
  final bool training;
  @override
  State<BattleScreen> createState() => _BattleScreenState();
}

class _BattleScreenState extends State<BattleScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  late GameEngine game;
  late final Ticker _ticker;
  late final GameSound sound;
  Duration _previous = Duration.zero;
  final FocusNode _focus = FocusNode();
  final Set<LogicalKeyboardKey> _keys = {};
  Offset? _anchor, _stick;
  int? _pointer;
  bool _rewarded = false;
  bool _returning = false;
  int reward = 0;
  String _runId = '';
  ui.Image? _shipImage, _enemyImage, _bossImage;
  Profile get p => widget.profile;
  bool get blocked => game.paused || game.choices.isNotEmpty || game.finished;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    sound = GameSound(p);
    _newGame();
    _loadArt();
    _ticker = createTicker(_tick)..start();
  }

  void _newGame() {
    _runId = DateTime.now().microsecondsSinceEpoch.toString();
    game = GameEngine(
      stageIndex: p.selectedStage,
      shipIndex: p.selectedShip,
      attackLevel: p.attackLevel,
      hullLevel: p.hullLevel,
      magnetLevel: p.magnetLevel,
      equipmentIndex: p.equipment,
      training: widget.training,
    )..onEvent = sound.play;
    _rewarded = false;
    reward = 0;
    _clearInput();
  }

  Future<ui.Image?> _decodeSprite(String asset, int width) async {
    try {
      final bytes = await rootBundle.load(asset);
      final codec = await ui.instantiateImageCodec(
        bytes.buffer.asUint8List(),
        targetWidth: width,
      );
      final frame = await codec.getNextFrame();
      codec.dispose();
      return frame.image;
    } catch (error) {
      debugPrint('Could not load sprite $asset: $error');
      return null;
    }
  }

  Future<void> _loadArt() async {
    final images = await Future.wait([
      _decodeSprite(ships[game.shipIndex].asset, 192),
      _decodeSprite('assets/art/shootingstar_enemy_hunter.png', 128),
      _decodeSprite('assets/art/shootingstar_boss_fortress.png', 320),
    ]);
    if (!mounted) {
      for (final image in images) {
        image?.dispose();
      }
      return;
    }
    setState(() {
      _shipImage = images[0];
      _enemyImage = images[1];
      _bossImage = images[2];
    });
  }

  void _tick(Duration time) {
    final dt = (time - _previous).inMicroseconds / 1000000;
    _previous = time;
    if (!mounted) return;
    if (!blocked) {
      game.update(dt);
      if (game.choices.isNotEmpty || game.finished) _clearInput();
    }
    if (game.finished && !_rewarded) {
      _rewarded = true;
      reward = p.completeRun(
        runId: _runId,
        victory: game.victory,
        stageIndex: game.stageIndex,
        kills: game.kills,
        level: game.level,
        seconds: game.elapsed.floor(),
        training: widget.training,
      );
    }
    setState(() {});
  }

  void _clearInput() {
    _keys.clear();
    _anchor = null;
    _stick = null;
    _pointer = null;
    game.input = Offset.zero;
  }

  void _pause() {
    if (game.finished) return;
    setState(() {
      game.setPaused(true);
      _clearInput();
      sound.stop();
    });
  }

  void _resume() {
    setState(() {
      game.setPaused(false);
      _clearInput();
    });
    _focus.requestFocus();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _pause();
  }

  KeyEventResult _key(FocusNode node, KeyEvent event) {
    final key = event.logicalKey;
    if (key == LogicalKeyboardKey.escape || key == LogicalKeyboardKey.keyP) {
      if (event is KeyDownEvent) {
        game.paused ? _resume() : _pause();
      }
      return KeyEventResult.handled;
    }
    final controls = {
      LogicalKeyboardKey.keyW,
      LogicalKeyboardKey.keyA,
      LogicalKeyboardKey.keyS,
      LogicalKeyboardKey.keyD,
      LogicalKeyboardKey.arrowUp,
      LogicalKeyboardKey.arrowDown,
      LogicalKeyboardKey.arrowLeft,
      LogicalKeyboardKey.arrowRight,
    };
    if (!controls.contains(key)) return KeyEventResult.ignored;
    if (blocked) {
      _clearInput();
      return KeyEventResult.handled;
    }
    if (event is KeyUpEvent) {
      _keys.remove(key);
    } else {
      _keys.add(key);
    }
    final x =
        (_keys.contains(LogicalKeyboardKey.keyD) ||
                _keys.contains(LogicalKeyboardKey.arrowRight)
            ? 1.0
            : 0.0) -
        (_keys.contains(LogicalKeyboardKey.keyA) ||
                _keys.contains(LogicalKeyboardKey.arrowLeft)
            ? 1.0
            : 0.0);
    final y =
        (_keys.contains(LogicalKeyboardKey.keyS) ||
                _keys.contains(LogicalKeyboardKey.arrowDown)
            ? 1.0
            : 0.0) -
        (_keys.contains(LogicalKeyboardKey.keyW) ||
                _keys.contains(LogicalKeyboardKey.arrowUp)
            ? 1.0
            : 0.0);
    game.input = Offset(x, y);
    return KeyEventResult.handled;
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _ticker.dispose();
    sound.dispose();
    _shipImage?.dispose();
    _enemyImage?.dispose();
    _bossImage?.dispose();
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: game.finished,
    onPopInvokedWithResult: (didPop, result) {
      if (!didPop) _pause();
    },
    child: Scaffold(
      body: SafeArea(
        child: Focus(
          autofocus: true,
          focusNode: _focus,
          onKeyEvent: _key,
          onFocusChange: (focused) {
            if (!focused &&
                !game.finished &&
                !game.paused &&
                game.choices.isEmpty) {
              _pause();
            }
          },
          child: LayoutBuilder(
            builder: (context, c) {
              final wide = c.maxWidth > 850;
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (wide)
                    SizedBox(
                      width: 220,
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: _sidePanel(),
                      ),
                    ),
                  Expanded(
                    child: Center(
                      child: AspectRatio(
                        aspectRatio: 420 / 800,
                        child: Column(
                          children: [
                            _hud(),
                            Expanded(
                              child: LayoutBuilder(
                                builder: (context, bounds) => ClipRRect(
                                  borderRadius: BorderRadius.circular(
                                    wide ? 18 : 0,
                                  ),
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Listener(
                                        onPointerDown: (e) {
                                          if (blocked || _pointer != null) {
                                            return;
                                          }
                                          _focus.requestFocus();
                                          _pointer = e.pointer;
                                          _anchor = e.localPosition;
                                          _stick = _anchor;
                                        },
                                        onPointerMove: (e) {
                                          if (blocked ||
                                              e.pointer != _pointer ||
                                              _anchor == null) {
                                            return;
                                          }
                                          final d = e.localPosition - _anchor!;
                                          _stick =
                                              _anchor! +
                                              (d.distance > 45
                                                  ? d / d.distance * 45
                                                  : d);
                                          game.input = d.distance < 5
                                              ? Offset.zero
                                              : d / 45;
                                        },
                                        onPointerUp: (e) {
                                          if (e.pointer == _pointer) {
                                            _clearInput();
                                          }
                                        },
                                        onPointerCancel: (e) {
                                          if (e.pointer == _pointer) {
                                            _clearInput();
                                          }
                                        },
                                        child: RepaintBoundary(
                                          child: CustomPaint(
                                            painter: BattlePainter(
                                              game,
                                              shipImage: _shipImage,
                                              enemyImage: _enemyImage,
                                              bossImage: _bossImage,
                                              reducedEffects: p.reducedEffects,
                                            ),
                                            size: Size.infinite,
                                          ),
                                        ),
                                      ),
                                      if (_anchor != null && !blocked)
                                        Positioned(
                                          left: _anchor!.dx - 44,
                                          top: _anchor!.dy - 44,
                                          child: IgnorePointer(
                                            child: Container(
                                              width: 88,
                                              height: 88,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: cyan.withValues(
                                                  alpha: .05,
                                                ),
                                                border: Border.all(
                                                  color: cyan.withValues(
                                                    alpha: .3,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (_stick != null && !blocked)
                                        Positioned(
                                          left: _stick!.dx - 15,
                                          top: _stick!.dy - 15,
                                          child: IgnorePointer(
                                            child: Container(
                                              width: 30,
                                              height: 30,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: cyan.withValues(
                                                  alpha: .4,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (game.elapsed < 6 && !blocked)
                                        const Positioned(
                                          left: 12,
                                          right: 12,
                                          bottom: 32,
                                          child: IgnorePointer(
                                            child: Center(
                                              child: Text(
                                                '드래그하여 비행  ·  공격은 자동',
                                                style: TextStyle(
                                                  color: cyan,
                                                  fontSize: 13,
                                                  fontWeight: FontWeight.bold,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      if (game.choices.isNotEmpty &&
                                          !game.finished &&
                                          !game.paused)
                                        _upgrades(),
                                      if (game.paused && !game.finished)
                                        _pausePanel(),
                                      if (game.finished) _result(),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 7,
                              ),
                              child: Row(
                                children: [
                                  const Icon(
                                    Icons.shield_outlined,
                                    color: cyan,
                                    size: 13,
                                  ),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      game.statusText,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: muted,
                                        fontSize: 10,
                                      ),
                                    ),
                                  ),
                                  if (widget.training)
                                    const Text(
                                      '훈련',
                                      style: TextStyle(
                                        color: cyan,
                                        fontSize: 10,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  if (wide) const SizedBox(width: 40),
                ],
              );
            },
          ),
        ),
      ),
    ),
  );
  Widget _hud() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 10, 10, 9),
    child: Column(
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Eyebrow(
                    widget.training
                        ? 'TRAINING / 45s'
                        : stages[game.stageIndex].subtitle,
                  ),
                  gap(3),
                  Text(
                    '${_clock(game.elapsed)} / ${_clock(game.duration)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 20,
                      fontFeatures: [ui.FontFeature.tabularFigures()],
                    ),
                  ),
                ],
              ),
            ),
            Text(
              'Lv.${game.level}',
              style: const TextStyle(
                color: cyan,
                fontWeight: FontWeight.w900,
                fontSize: 20,
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              tooltip: '일시정지',
              onPressed: game.finished ? null : _pause,
              icon: const Icon(Icons.pause_circle_outline, size: 29),
            ),
          ],
        ),
        Row(
          children: [
            const Icon(Icons.favorite, size: 12, color: Color(0xFFFF8D8D)),
            const SizedBox(width: 6),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: (game.hp / game.maxHp).clamp(0, 1),
                  minHeight: 6,
                  color: const Color(0xFFFF8D8D),
                  backgroundColor: panel,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              '${game.hp.ceil()} / ${game.maxHp.ceil()}',
              style: const TextStyle(fontSize: 10, color: muted),
            ),
          ],
        ),
        gap(7),
        LinearProgressIndicator(
          value: (game.xp / game.xpNeeded).clamp(0, 1),
          minHeight: 3,
          color: cyan,
          backgroundColor: panel,
        ),
        if (game.boss != null)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Column(
              children: [
                const Text(
                  '보스 · 공허의 파수꾼',
                  style: TextStyle(fontSize: 10, color: Color(0xFFFFBD7A)),
                ),
                gap(3),
                LinearProgressIndicator(
                  value: game.bossHealth.clamp(0, 1),
                  minHeight: 5,
                  color: const Color(0xFFFFBD7A),
                  backgroundColor: panel,
                ),
              ],
            ),
          ),
      ],
    ),
  );
  Widget _sidePanel() => Column(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Eyebrow('LIVE TELEMETRY'),
      gap(12),
      Text(
        ships[p.selectedShip].name,
        style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w800),
      ),
      gap(6),
      Text(stages[game.stageIndex].name, style: const TextStyle(color: muted)),
      gap(30),
      Stat('${game.kills}', '격파한 적'),
      gap(28),
      const Eyebrow('ARSENAL'),
      gap(10),
      for (final entry in game.upgrades.entries)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            children: [
              Icon(
                _weaponIcon(entry.key),
                size: 16,
                color:
                    entry.value >= 4 &&
                        const ['gun', 'missile', 'drone'].contains(entry.key)
                    ? const Color(0xFFFFBD7A)
                    : cyan,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  _weaponName(entry.key),
                  style: const TextStyle(fontSize: 12),
                ),
              ),
              Text(
                entry.value >= 4 &&
                        const ['gun', 'missile', 'drone'].contains(entry.key)
                    ? '진화'
                    : '${entry.value}',
                style: const TextStyle(color: cyan, fontSize: 12),
              ),
            ],
          ),
        ),
      gap(28),
      const Text(
        'W A S D / 방향키\n이동 및 선회\n\nESC / P\n일시정지',
        style: TextStyle(fontSize: 11, height: 1.8, color: muted),
      ),
    ],
  );
  Widget _scrim(Widget child) => Container(
    color: ink.withValues(alpha: .94),
    alignment: Alignment.center,
    child: SingleChildScrollView(
      padding: const EdgeInsets.all(22),
      child: child,
    ),
  );
  Widget _upgrades() => _scrim(
    Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Eyebrow('SIGNAL AMPLIFIED'),
        gap(8),
        Text(
          'Lv.${game.level} · 진화의 갈림길',
          style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
        ),
        gap(6),
        const Text(
          '하나를 선택하세요. 전투는 잠시 멈춥니다.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
        gap(20),
        for (final choice in game.choices)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Semantics(
              button: true,
              label: choice.title,
              child: InkWell(
                key: Key('upgrade-${choice.id}'),
                onTap: () {
                  sound.play('level');
                  setState(() {
                    game.chooseUpgrade(choice.id);
                    _clearInput();
                  });
                  _focus.requestFocus();
                },
                borderRadius: BorderRadius.circular(18),
                child: Surface(
                  active: choice.evolution,
                  padding: const EdgeInsets.all(18),
                  child: Row(
                    children: [
                      Icon(
                        _weaponIcon(choice.iconKey),
                        color: choice.evolution
                            ? const Color(0xFFFFBD7A)
                            : cyan,
                        size: 26,
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              choice.title,
                              style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                fontSize: 16,
                              ),
                            ),
                            gap(5),
                            Text(
                              choice.description,
                              style: const TextStyle(
                                fontSize: 12,
                                color: muted,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.add, size: 20, color: cyan),
                    ],
                  ),
                ),
              ),
            ),
          ),
      ],
    ),
  );
  Widget _pausePanel() => _scrim(
    Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const Icon(Icons.pause_circle_outline, color: cyan, size: 44),
        gap(16),
        const Text(
          '궤도 대기',
          style: TextStyle(fontSize: 29, fontWeight: FontWeight.w800),
        ),
        gap(8),
        const Text(
          '잠시 숨을 고르세요. 항로는 기다립니다.',
          textAlign: TextAlign.center,
          style: TextStyle(color: muted, fontSize: 12),
        ),
        gap(28),
        SizedBox(
          width: double.infinity,
          child: FilledButton(onPressed: _resume, child: const Text('계속 비행')),
        ),
        gap(10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () {
              setState(() {
                game.abandon();
                _clearInput();
              });
            },
            child: const Text('귀환 · 현재 보상 정산'),
          ),
        ),
        gap(16),
        const Text(
          '전투 시간과 적의 공격이 멈춰 있습니다.',
          style: TextStyle(color: muted, fontSize: 11),
        ),
      ],
    ),
  );
  Widget _result() => _scrim(
    Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Eyebrow(
          game.victory ? 'MISSION COMPLETE' : 'SIGNAL RECOVERED',
          color: game.victory ? cyan : const Color(0xFFFFBD7A),
        ),
        gap(15),
        Icon(
          game.victory ? Icons.auto_awesome : Icons.satellite_alt,
          color: game.victory ? cyan : const Color(0xFFFFBD7A),
          size: 52,
        ),
        gap(15),
        Text(
          game.victory ? '항로를 밝혔습니다' : '다음 궤적을 향해',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 29, fontWeight: FontWeight.w900),
        ),
        gap(8),
        Text(
          widget.training
              ? '훈련 완료 · 실전에서 항로를 정복하세요'
              : game.victory
              ? '수신 성공. 당신의 잔광이 길이 됩니다.'
              : '회수한 신호로 더 강한 기체를 만드세요.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, color: muted),
        ),
        gap(25),
        Surface(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Stat('${game.kills}', '격파'),
              Stat('Lv.${game.level}', '최종 레벨'),
              Stat(_clock(game.elapsed), '비행 시간'),
            ],
          ),
        ),
        gap(16),
        Text(
          widget.training ? '훈련에는 보상이 없습니다' : '+ $reward C',
          style: TextStyle(
            color: cyan,
            fontSize: widget.training ? 14 : 32,
            fontWeight: FontWeight.w800,
          ),
        ),
        gap(6),
        Text(
          widget.training
              ? '진행과 기록에 영향을 주지 않습니다.'
              : p.saveError ?? '보상과 진행이 자동 저장됩니다.',
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted, fontSize: 11),
        ),
        gap(24),
        SizedBox(
          width: double.infinity,
          child: FilledButton(
            onPressed: () {
              sound.play('click');
              setState(_newGame);
              _focus.requestFocus();
            },
            child: const Text('다시 출격'),
          ),
        ),
        gap(10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () {
              if (_returning) return;
              _returning = true;
              Navigator.of(context).pop(true);
            },
            child: const Text('격납고로 귀환'),
          ),
        ),
      ],
    ),
  );
}

String _clock(double seconds) {
  final v = seconds.floor();
  return '${(v ~/ 60).toString().padLeft(2, '0')}:${(v % 60).toString().padLeft(2, '0')}';
}

String _weaponName(String id) => switch (id) {
  'gun' => '펄스 주포',
  'missile' => '유도 미사일',
  'drone' => '호위 드론',
  'side' => '측면 포',
  'mine' => '후방 기뢰',
  'trail' => '에너지 항적',
  'magnet' => '회수 자기장',
  _ => id,
};
IconData _weaponIcon(String id) => switch (id) {
  'gun' => Icons.bolt,
  'missile' => Icons.rocket_launch,
  'drone' => Icons.shield_outlined,
  'side' => Icons.compare_arrows,
  'mine' => Icons.blur_on,
  'trail' => Icons.waves,
  'hull' => Icons.favorite_border,
  'repair' => Icons.favorite_border,
  'magnet' => Icons.radar,
  _ => Icons.auto_awesome,
};
