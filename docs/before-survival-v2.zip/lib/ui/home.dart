import 'package:flutter/material.dart';

import '../data/content.dart';
import '../data/profile.dart';
import '../main.dart';
import 'components.dart';
import 'battle.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.profile});
  final Profile profile;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  bool _launching = false;
  Profile get p => widget.profile;
  @override
  void initState() {
    super.initState();
    p.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    p.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _launch({bool training = false}) async {
    if (_launching) return;
    _launching = true;
    try {
      if (!p.onboarded) {
        await showGuide(context, p.finishOnboarding);
        if (!mounted) return;
      }
      final toHangar = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(
          builder: (_) => BattleScreen(profile: p, training: training),
        ),
      );
      if (mounted && toHangar == true) setState(() => tab = 1);
    } finally {
      _launching = false;
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1220),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 20,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        border: Border.all(color: cyan),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: const Icon(
                        Icons.auto_awesome,
                        size: 20,
                        color: cyan,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SHOOTINGSTAR',
                            style: TextStyle(
                              fontSize: 13,
                              letterSpacing: 2.7,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            '잔광의 항로',
                            style: TextStyle(color: muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.hexagon_outlined,
                      color: Color(0xFFFFBD7A),
                      size: 19,
                    ),
                    const SizedBox(width: 7),
                    Text(
                      '${p.credits}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: '설정',
                      onPressed: () => _settings(context),
                      icon: const Icon(Icons.tune, size: 21),
                    ),
                  ],
                ),
              ),
              Expanded(child: tab == 0 ? _bridge() : _hangar()),
              if (p.saveError != null)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    p.saveError!,
                    style: const TextStyle(color: Colors.orange),
                  ),
                ),
              NavigationBar(
                height: 66,
                selectedIndex: tab,
                onDestinationSelected: (i) => setState(() => tab = i),
                backgroundColor: ink,
                destinations: const [
                  NavigationDestination(icon: Icon(Icons.radar), label: '출격'),
                  NavigationDestination(
                    icon: Icon(Icons.rocket_launch_outlined),
                    label: '격납고',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
  Widget _bridge() => LayoutBuilder(
    builder: (context, c) {
      final wide = c.maxWidth > 800;
      final hero = _hero(wide);
      final missions = _missions();
      if (wide) {
        return Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Expanded(flex: 6, child: hero),
              const SizedBox(width: 24),
              Expanded(flex: 5, child: SingleChildScrollView(child: missions)),
            ],
          ),
        );
      }
      return SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
        child: Column(
          children: [
            SizedBox(height: 330, child: hero),
            gap(24),
            missions,
          ],
        ),
      );
    },
  );
  Widget _hero(bool wide) => ClipRRect(
    borderRadius: BorderRadius.circular(24),
    child: Stack(
      fit: StackFit.expand,
      children: [
        Image.asset(
          'assets/art/shootingstar_title_art.png',
          fit: BoxFit.cover,
          alignment: Alignment.bottomCenter,
          errorBuilder: (_, _, _) => Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF102C45), ink],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: const Center(
              child: Icon(Icons.rocket_launch, size: 130, color: cyan),
            ),
          ),
        ),
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xC0080F1E), Color(0x00080F1E), Color(0xE6080F1E)],
              stops: [0, .56, 1],
            ),
          ),
        ),
        Padding(
          padding: EdgeInsets.all(wide ? 34 : 26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Eyebrow('A SIGNAL BEYOND THE DARK'),
              gap(14),
              Text(
                '어둠을 가르는\n당신의 궤적.',
                style: TextStyle(
                  fontSize: wide ? 42 : 30,
                  height: 1.25,
                  fontWeight: FontWeight.w900,
                  letterSpacing: -1,
                ),
              ),
              gap(12),
              const Text(
                '작은 기체. 끝없는 가능성.',
                style: TextStyle(color: Color(0xFFCFDFE9), fontSize: 14),
              ),
              const Spacer(),
              Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: cyan,
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Text(
                    'OFFLINE FLIGHT / 01',
                    style: TextStyle(
                      fontSize: 10,
                      letterSpacing: 2,
                      color: cyan,
                    ),
                  ),
                  const Spacer(),
                  const Icon(Icons.north_east, color: cyan),
                ],
              ),
            ],
          ),
        ),
      ],
    ),
  );
  Widget _missions() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Eyebrow('FLIGHT DECK'),
      gap(8),
      const Text(
        '다음 항로를 선택하세요',
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w800,
          letterSpacing: -.5,
        ),
      ),
      gap(6),
      const Text(
        '생존하고, 진화하고, 마지막 신호를 지키세요.',
        style: TextStyle(color: muted, fontSize: 13),
      ),
      gap(22),
      for (int i = 0; i < stages.length; i++)
        Padding(padding: const EdgeInsets.only(bottom: 10), child: _stage(i)),
      gap(10),
      Surface(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              Icons.rocket_launch,
              color: ships[p.selectedShip].color,
              size: 23,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    ships[p.selectedShip].name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    equipmentOptions[p.equipment].name,
                    style: const TextStyle(fontSize: 11, color: muted),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () => setState(() => tab = 1),
              child: const Text('기체 변경'),
            ),
          ],
        ),
      ),
      gap(16),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          key: const Key('launch'),
          onPressed: _launch,
          icon: const Icon(Icons.arrow_upward, size: 19),
          label: Text('${stages[p.selectedStage].name} · 출격'),
        ),
      ),
      gap(8),
      Row(
        children: [
          Expanded(
            child: TextButton.icon(
              onPressed: () => _launch(training: true),
              icon: const Icon(Icons.sports_esports_outlined, size: 18),
              label: const Text('45초 훈련'),
            ),
          ),
          TextButton(
            onPressed: () => showGuide(context, () {}),
            child: const Text('비행 가이드'),
          ),
        ],
      ),
      gap(12),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Stat('${p.runs}', '완료한 출격'),
          Stat('${p.bestKills}', '최고 격파'),
          Stat('${p.clearedStages.length} / 3', '정복한 항로'),
        ],
      ),
      gap(18),
    ],
  );
  Widget _stage(int i) {
    final s = stages[i];
    final unlocked = p.canStage(i);
    final active = p.selectedStage == i;
    return Semantics(
      button: true,
      selected: active,
      label: '${s.name} ${unlocked ? '항로 선택' : '잠김'}',
      child: InkWell(
        onTap: unlocked ? () => p.selectStage(i) : null,
        borderRadius: BorderRadius.circular(18),
        child: Surface(
          active: active,
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 48,
                decoration: BoxDecoration(
                  color: s.color.withValues(alpha: unlocked ? 0.1 : 0.04),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  unlocked
                      ? (i == 0
                            ? Icons.blur_circular
                            : i == 1
                            ? Icons.flare
                            : Icons.brightness_2)
                      : Icons.lock_outline,
                  color: unlocked ? s.color : muted,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Eyebrow(s.subtitle, color: unlocked ? s.color : muted),
                    gap(4),
                    Text(
                      s.name,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: unlocked ? Colors.white : muted,
                      ),
                    ),
                    gap(3),
                    Text(
                      unlocked
                          ? '${s.duration ~/ 60}분 ${s.duration % 60}초  /  ${s.difficulty}'
                          : '이전 항로 클리어 시 개방',
                      style: const TextStyle(fontSize: 11, color: muted),
                    ),
                  ],
                ),
              ),
              if (p.clearedStages.contains(i))
                const Icon(Icons.check_circle_outline, color: cyan, size: 20)
              else
                Icon(
                  active ? Icons.radio_button_checked : Icons.chevron_right,
                  color: active ? cyan : muted,
                  size: 20,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hangar() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(24, 4, 24, 28),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Eyebrow('HANGAR / MAKE IT YOURS'),
        gap(8),
        const Text(
          '당신만의 비행을 설계하세요',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
        ),
        gap(8),
        const Text(
          '출격에서 얻은 크레딧으로 기체와 시스템을 강화합니다.',
          style: TextStyle(color: muted),
        ),
        gap(24),
        LayoutBuilder(
          builder: (context, c) => Wrap(
            spacing: 14,
            runSpacing: 14,
            children: [
              for (int i = 0; i < ships.length; i++)
                SizedBox(
                  width: c.maxWidth > 760 ? (c.maxWidth - 28) / 3 : c.maxWidth,
                  child: _ship(i),
                ),
            ],
          ),
        ),
        gap(30),
        const Eyebrow('LOADOUT'),
        gap(8),
        const Text(
          '장착 모듈',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        gap(12),
        for (int i = 0; i < equipmentOptions.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              onTap: () => p.selectEquipment(i),
              borderRadius: BorderRadius.circular(18),
              child: Surface(
                active: p.equipment == i,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 15,
                ),
                child: Row(
                  children: [
                    Icon(
                      i == 0
                          ? Icons.shield_outlined
                          : i == 1
                          ? Icons.bolt
                          : Icons.track_changes,
                      color: equipmentOptions[i].color,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            equipmentOptions[i].name,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            equipmentOptions[i].detail,
                            style: const TextStyle(color: muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    if (p.equipment == i)
                      const Icon(Icons.check_circle, color: cyan, size: 20),
                  ],
                ),
              ),
            ),
          ),
        gap(24),
        const Eyebrow('PERMANENT SYSTEMS'),
        gap(8),
        const Text(
          '영구 업그레이드',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        gap(12),
        _upgrade('attack', '증폭 회로', '모든 무기 공격력 +8% / 단계', Icons.bolt),
        gap(8),
        _upgrade('hull', '복합 장갑', '최대 내구도 +12% / 단계', Icons.shield_outlined),
        gap(8),
        _upgrade('magnet', '회수 안테나', '경험치 회수 범위 +15% / 단계', Icons.radar),
      ],
    ),
  );
  Widget _ship(int i) {
    final s = ships[i];
    final owned = p.unlockedShips.contains(i);
    return Surface(
      active: p.selectedShip == i,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Eyebrow('FRAME / 0${i + 1}', color: s.color),
              const Spacer(),
              if (p.selectedShip == i)
                const Icon(Icons.check_circle, color: cyan, size: 18),
            ],
          ),
          gap(10),
          Center(
            child: SizedBox(
              height: 120,
              child: Image.asset(
                s.asset,
                fit: BoxFit.contain,
                filterQuality: FilterQuality.medium,
                errorBuilder: (_, _, _) =>
                    Icon(Icons.rocket_launch, size: 70, color: s.color),
              ),
            ),
          ),
          Text(
            s.name,
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
          ),
          Text(s.tagline, style: TextStyle(color: s.color, fontSize: 12)),
          gap(12),
          Text(s.detail, style: const TextStyle(color: muted, fontSize: 12)),
          gap(16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Stat('${s.health.toInt()}', '내구도'),
              Stat('${s.speed.toInt()}', '기동력'),
              Stat('${(s.damage * 100).round()}%', '화력'),
            ],
          ),
          gap(18),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: owned
                  ? () => p.selectShip(i)
                  : p.credits >= s.unlockCost
                  ? () {
                      p.unlockShip(i);
                      p.selectShip(i);
                    }
                  : null,
              child: Text(
                owned
                    ? (p.selectedShip == i ? '선택됨' : '기체 선택')
                    : '${s.unlockCost} C · 해금',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _upgrade(String id, String title, String detail, IconData icon) {
    final level = p.upgradeLevel(id);
    final max = level >= maxUpgradeLevel;
    final cost = upgradeCost(level);
    return Surface(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: cyan),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$title  $level / $maxUpgradeLevel',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  detail,
                  style: const TextStyle(fontSize: 11, color: muted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: max || p.credits < cost ? null : () => p.buyUpgrade(id),
            child: Text(max ? 'MAX' : '$cost C'),
          ),
        ],
      ),
    );
  }

  Future<void> _settings(BuildContext context) => showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, update) => AlertDialog(
        title: const Text('비행 설정'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('효과음'),
                  value: p.soundEnabled,
                  onChanged: (v) {
                    p.updateSettings(soundEnabled: v);
                    update(() {});
                  },
                ),
                Text(
                  '음량 ${(p.volume * 100).round()}%',
                  style: const TextStyle(color: muted),
                ),
                Slider(
                  value: p.volume,
                  label: '${(p.volume * 100).round()}%',
                  onChanged: (v) {
                    p.updateSettings(volume: v);
                    update(() {});
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('시각 효과 줄이기'),
                  subtitle: const Text('입자와 화면 효과를 줄입니다'),
                  value: p.reducedEffects,
                  onChanged: (v) {
                    p.updateSettings(reducedEffects: v);
                    update(() {});
                  },
                ),
                gap(16),
                const Text(
                  '진행은 이 기기에 자동 저장됩니다.\n브라우저 데이터 삭제 시 기록이 지워질 수 있습니다.\n진행 중인 전투는 저장되지 않습니다.',
                  style: TextStyle(color: muted, fontSize: 12),
                ),
                gap(16),
                const Text(
                  'SHOOTINGSTAR 1.0.0\n광고 · 결제 · 계정 없이 플레이',
                  style: TextStyle(color: muted, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => showLicensePage(
              context: context,
              applicationName: 'Shootingstar',
              applicationVersion: '1.0.0',
            ),
            child: const Text('오픈소스 라이선스'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('완료'),
          ),
        ],
      ),
    ),
  );
}
