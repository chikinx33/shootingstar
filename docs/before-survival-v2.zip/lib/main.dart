import 'package:flutter/material.dart';

import 'data/profile.dart';
import 'ui/home.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final profile = await Profile.load();
  runApp(ShootingstarApp(profile: profile));
}

const ink = Color(0xFF080F1E);
const panel = Color(0xFF121F31);
const cyan = Color(0xFF75F4E1);
const muted = Color(0xFF9AACC1);

class ShootingstarApp extends StatelessWidget {
  const ShootingstarApp({super.key, required this.profile});
  final Profile profile;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Shootingstar · 잔광의 항로',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: ink,
      colorScheme: const ColorScheme.dark(
        primary: cyan,
        secondary: Color(0xFFFFBD7A),
        surface: panel,
      ),
      fontFamily: 'NotoSansKR',
      textTheme: const TextTheme(
        bodyMedium: TextStyle(fontSize: 14, height: 1.5),
        bodySmall: TextStyle(color: muted, height: 1.5),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          foregroundColor: ink,
          backgroundColor: cyan,
          minimumSize: const Size(48, 52),
          textStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: Colors.white,
          minimumSize: const Size(48, 48),
          side: const BorderSide(color: Color(0xFF314459)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
      sliderTheme: const SliderThemeData(
        showValueIndicator: ShowValueIndicator.onDrag,
      ),
    ),
    home: HomeScreen(profile: profile),
  );
}
