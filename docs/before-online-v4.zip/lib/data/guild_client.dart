import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import 'profile.dart';

class GuildClient {
  GuildClient(this.profile);
  final Profile profile;
  Future<Map<String, dynamic>> call(
    String action, [
    Map<String, dynamic> data = const {},
  ]) async {
    const configured = String.fromEnvironment('GUILD_API');
    final base = configured.isNotEmpty
        ? configured
        : (kIsWeb ? Uri.base.origin : 'http://127.0.0.1:8787');
    final response = await http
        .post(
          Uri.parse('$base/api/$action'),
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${profile.guildToken}',
          },
          body: jsonEncode(data),
        )
        .timeout(const Duration(seconds: 6));
    final value = jsonDecode(response.body) as Map<String, dynamic>;
    if (response.statusCode != 200) {
      throw Exception(value['error'] ?? '길드 서버 오류');
    }
    for (final reward in (value['rewards'] as List? ?? [])) {
      profile.acceptServerReward(Map<String, dynamic>.from(reward));
    }
    return value;
  }

  Future<void> syncReports() async {
    for (final report in List<Map<String, dynamic>>.from(
      profile.guildReports,
    )) {
      await call('report', report);
      profile.guildReports.remove(report);
      profile.contentChanged();
    }
  }
}
