import 'package:flutter/material.dart';

import '../data/profile.dart';
import '../data/guild_client.dart';
import '../main.dart';
import 'components.dart';

class GuildScreen extends StatefulWidget {
  const GuildScreen({super.key, required this.profile});
  final Profile profile;
  @override
  State<GuildScreen> createState() => _GuildScreenState();
}

class _GuildScreenState extends State<GuildScreen> {
  Map<String, dynamic>? state;
  bool busy = false;
  String? error;
  final name = TextEditingController(), code = TextEditingController();
  late final client = GuildClient(widget.profile);
  @override
  void initState() {
    super.initState();
    if (widget.profile.guildToken.isNotEmpty) run('state');
  }

  @override
  void dispose() {
    name.dispose();
    code.dispose();
    super.dispose();
  }

  Future<void> run(
    String action, [
    Map<String, dynamic> data = const {},
  ]) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (action == 'register') {
        final result = await client.call(action, {'name': name.text});
        widget.profile.guildToken = result['token'];
        widget.profile.guildNickname = name.text.trim();
        widget.profile.contentChanged();
        action = 'state';
      }
      var result = await client.call(action, data);
      if (result['guild'] != null && widget.profile.guildReports.isNotEmpty) {
        await client.syncReports();
        result = await client.call('state');
      }
      if (mounted) setState(() => state = result);
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e.toString().startsWith('Exception:')
              ? e.toString().substring(11)
              : '길드 서버에 연결할 수 없습니다. 로컬 실행 서버를 확인한 뒤 다시 연결하세요.',
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.profile, g = state?['guild'], user = state?['user'];
    return Scaffold(
      appBar: AppBar(
        title: const Text('성간 길드'),
        actions: [
          IconButton(
            onPressed: busy || p.guildToken.isEmpty ? null : () => run('state'),
            icon: const Icon(Icons.refresh),
            tooltip: '길드 새로고침',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            '함께 성장하는 함대',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
          ),
          gap(8),
          const Text(
            '길드 출석 → 기여 → 주간 토벌 → 보급. 초대 코드로 같은 서버의 동료와 합류하세요.',
            style: TextStyle(color: muted),
          ),
          gap(),
          if (busy) const LinearProgressIndicator(),
          if (error != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Text(error!, style: const TextStyle(color: Colors.orange)),
            ),
          if (p.guildToken.isEmpty) ...[
            TextField(
              controller: name,
              maxLength: 16,
              decoration: const InputDecoration(labelText: '길드에서 사용할 닉네임'),
            ),
            FilledButton(
              onPressed: busy ? null : () => run('register'),
              child: const Text('길드 프로필 등록'),
            ),
          ] else if (state == null)
            FilledButton(
              onPressed: busy ? null : () => run('state'),
              child: const Text('서버 다시 연결'),
            )
          else if (g == null) ...[
            TextField(
              controller: name,
              maxLength: 24,
              decoration: const InputDecoration(labelText: '새 길드 이름'),
            ),
            FilledButton(
              onPressed: busy ? null : () => run('create', {'name': name.text}),
              child: const Text('길드 창설'),
            ),
            gap(),
            TextField(
              controller: code,
              maxLength: 6,
              decoration: const InputDecoration(labelText: '6자리 초대 코드'),
            ),
            OutlinedButton(
              onPressed: busy ? null : () => run('join', {'code': code.text}),
              child: const Text('초대 코드로 가입'),
            ),
            gap(),
            const Text(
              '모집 중인 길드',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            if ((state!['directory'] as List).isEmpty)
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text('첫 길드를 창설해 보세요.'),
              ),
            for (final guild in state!['directory'])
              ListTile(
                title: Text(guild['name']),
                subtitle: Text('${guild['members']} / 20명 · ${guild['id']}'),
                trailing: TextButton(
                  onPressed: busy
                      ? null
                      : () => run('join', {'code': guild['id']}),
                  child: const Text('가입'),
                ),
              ),
          ] else ...[
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    g['name'],
                    style: const TextStyle(
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SelectableText('초대 코드 ${g['id']}'),
                  gap(8),
                  Text(
                    'Lv.${1 + (g['xp'] as int) ~/ 200} · 기여 경험치 ${g['xp']} · ${(state!['members'] as List).length}/20명',
                  ),
                  Text(
                    '내 길드 코인 ${user['coins']}',
                    style: const TextStyle(color: cyan),
                  ),
                  gap(8),
                  Wrap(
                    spacing: 8,
                    children: [
                      FilledButton(
                        onPressed: busy || user['checkday'] == state!['day']
                            ? null
                            : () => run('checkin'),
                        child: Text(
                          user['checkday'] == state!['day']
                              ? '오늘 출석 완료'
                              : '출석 · 코인 +10',
                        ),
                      ),
                      OutlinedButton(
                        onPressed: busy || (user['coins'] as int) < 10
                            ? null
                            : () => run('donate'),
                        child: const Text('기여 · 코인 10'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            gap(),
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '주간 토벌 · ${state!['week']}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  gap(8),
                  LinearProgressIndicator(
                    value: ((state!['damage'] as int) / 100000).clamp(0, 1),
                  ),
                  gap(8),
                  Text(
                    '${state!['damage']} / 100,000 피해 · 오늘 ${state!['attempts']}/3회',
                  ),
                  const Text(
                    '30초·10격파 이상 일반 출격이 자동 기여됩니다. 1격파 = 피해 3, 1회 최대 3,000. 월요일 초기화.',
                    style: TextStyle(color: muted, fontSize: 12),
                  ),
                  FilledButton(
                    onPressed: busy || (state!['damage'] as int) < 100000
                        ? null
                        : () => run('raid'),
                    child: const Text('토벌 보상 우편 수령'),
                  ),
                ],
              ),
            ),
            gap(),
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '길드 보급소',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const Text('먹이 30 + 설계도 2 · 하루 1회'),
                  FilledButton(
                    onPressed: busy || (user['coins'] as int) < 10
                        ? null
                        : () => run('shop'),
                    child: const Text('길드 코인 10 · 우편 지급'),
                  ),
                ],
              ),
            ),
            gap(),
            const Text(
              '길드원',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            for (final member in state!['members'])
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: Text(member['name']),
              ),
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      final yes = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('길드 탈퇴'),
                          content: const Text('공동 토벌 참여를 종료합니다. 탈퇴할까요?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(c, false),
                              child: const Text('취소'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(c, true),
                              child: const Text('탈퇴'),
                            ),
                          ],
                        ),
                      );
                      if (yes == true) run('leave');
                    },
              child: const Text('길드 탈퇴'),
            ),
          ],
          gap(),
          const Text(
            '현재 PC의 길드 서버에 연결됩니다. 다른 기기와 인터넷 길드를 이용하려면 공유 서버 운영이 필요합니다.',
            style: TextStyle(color: muted, fontSize: 12),
          ),
        ],
      ),
    );
  }
}
