import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shootingstar/data/profile.dart';
import 'package:shootingstar/ui/content_hub.dart';

void main() {
  testWidgets(
    '360px content tabs, merge review and pet feeding work without overflow',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({});
      final p = await Profile.load();
      p.grantItem(0);
      p.grantItem(0);
      p.blueprints = 2;
      await tester.pumpWidget(
        MaterialApp(
          theme: ThemeData.dark(),
          home: Scaffold(body: ContentHub(profile: p)),
        ),
      );
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      await tester.tap(find.text('일반 +0').first);
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.text('동일 장비 3개 합성'));
      await tester.tap(find.text('동일 장비 3개 합성'));
      await tester.pumpAndSettle();
      expect(find.text('합성 재료 확인'), findsOneWidget);
      await tester.tap(find.text('합성 확정'));
      await tester.pumpAndSettle();
      expect(p.gearAt(0).rank, 1);
      await tester.tap(find.text('닫기'));
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(ChoiceChip, '펫'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('먹이 10 · 육성').first);
      await tester.pumpAndSettle();
      expect(p.petLevels[0], 2);
      expect(tester.takeException(), isNull);
      for (final name in ['테크', '보급', '시즌']) {
        final chip = find.widgetWithText(ChoiceChip, name);
        await tester.ensureVisible(chip);
        await tester.tap(chip);
        await tester.pumpAndSettle();
        expect(tester.takeException(), isNull);
      }
      await tester.pumpWidget(const SizedBox());
      p.dispose();
    },
  );
}
