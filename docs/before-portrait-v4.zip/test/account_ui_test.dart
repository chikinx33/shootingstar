import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shootingstar/data/profile.dart';
import 'package:shootingstar/data/cloud_sync.dart';
import 'package:shootingstar/ui/account_screen.dart';

void main() {
  testWidgets('account forms and conflict choices fit a 360px display', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final p = await Profile.load();
    final c = CloudSync(p)..ready = true;
    await tester.pumpWidget(MaterialApp(home: AccountScreen(profile: p)));
    await tester.pumpAndSettle();
    expect(find.text('계정 · 클라우드 저장'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('가입'));
    await tester.pumpAndSettle();
    expect(find.text('현재 진행으로 계정 만들기'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('복구'));
    await tester.pumpAndSettle();
    expect(find.text('48자리 복구 코드'), findsOneWidget);
    expect(tester.takeException(), isNull);
    c.account = {'id': 'one', 'username': 'qa', 'nickname': 'QA'};
    c.conflict = {'revision': 2, 'profile': Profile.freshProgress()};
    await tester.pumpWidget(
      MaterialApp(
        home: AccountScreen(key: const ValueKey('signed-in'), profile: p),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('서버 진행 사용'), findsOneWidget);
    expect(find.text('이 기기 진행 저장'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    c.dispose();
  });
}
