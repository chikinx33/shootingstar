class GearSpec {
  const GearSpec(this.name, this.slot, this.perk, {this.weapon = 'gun'});
  final String name, perk, weapon;
  final int slot;
}

const gearCatalog = [
  GearSpec('펄스 블래스터', 0, '전방위 자동 조준 주포로 시작'),
  GearSpec('유성 추적기', 0, '추적 로켓으로 시작', weapon: 'missile'),
  GearSpec('매의 눈 센서', 1, '등급마다 화력 추가 +2%'),
  GearSpec('수집 스캐너', 1, '등급마다 회수 반경 +10%'),
  GearSpec('항성 출력 코어', 2, '등급마다 화력 추가 +3%'),
  GearSpec('순환 에너지 코어', 2, '등급마다 쿨다운 −2%'),
  GearSpec('티타늄 선체', 3, '등급마다 선체 추가 +4%'),
  GearSpec('재생 선체', 3, '30초마다 최대 선체의 2% 회복'),
  GearSpec('방벽 벨트', 4, '등급마다 받는 피해 −2%'),
  GearSpec('생명 유지 벨트', 4, '등급마다 선체 추가 +3%'),
  GearSpec('고속 추진기', 5, '등급마다 이동 속도 +3%'),
  GearSpec('회수 추진기', 5, '등급마다 회수 반경 +8%'),
];
const qualityNames = ['일반', '우수', '희귀', '엘리트', '에픽', '전설'];
const slotNames = ['주무장', '센서', '코어', '선체', '벨트', '추진기'];
const techWeapons = [
  'gun',
  'missile',
  'drone',
  'side',
  'mine',
  'trail',
  'guardian',
  'lightning',
];
const techNames = [
  '관통 증폭기',
  '폭발 유도 칩',
  '자동 추적 AI',
  '분광 렌즈',
  '중력 응축기',
  '플라스마 전지',
  '궤도 확장기',
  '연쇄 축전기',
];
const techPerks = [
  '주포 1회 관통',
  '로켓 폭발 반경 +60%',
  '드론 탄환 적 추적',
  '광자탄 2발 추가',
  '지뢰 폭발 반경 +50%',
  '장판 지속 시간 +50%',
  '수호자 범위 +20%',
  '낙뢰 타격 2회 추가',
];
const petNames = ['루미 · 돌격형', '미오 · 회복형', '볼트 · 수호형'];
const petDescriptions = [
  '적에게 에너지탄 발사 · Lv.5부터 2연사',
  '주기적으로 선체 회복 · 보조 배치 시 회수 반경 증가',
  '주변 적 탄환 제거 · 보조 배치 시 받는 피해 감소',
];

int boundedInt(dynamic value, int fallback, int max) =>
    value is num && value.isFinite ? value.toInt().clamp(0, max) : fallback;

class GearItem {
  GearItem(
    this.id,
    this.spec, {
    this.rank = 0,
    this.level = 0,
    this.locked = false,
    this.spentCredits = 0,
    this.spentPlans = 0,
  });
  final int id, spec;
  int rank, level, spentCredits, spentPlans;
  bool locked;
  GearSpec get definition => gearCatalog[spec];
  Map<String, dynamic> toJson() => {
    'id': id,
    'spec': spec,
    'rank': rank,
    'level': level,
    'locked': locked,
    'spentCredits': spentCredits,
    'spentPlans': spentPlans,
  };
  static GearItem? restore(dynamic value) {
    if (value is! Map ||
        value['id'] is! int ||
        value['id'] <= 0 ||
        value['spec'] is! int ||
        value['spec'] < 0 ||
        value['spec'] >= gearCatalog.length) {
      return null;
    }
    return GearItem(
      value['id'],
      value['spec'],
      rank: boundedInt(value['rank'], 0, 5),
      level: boundedInt(value['level'], 0, 70),
      locked: value['locked'] == true,
      spentCredits: boundedInt(value['spentCredits'], 0, 1000000),
      spentPlans: boundedInt(value['spentPlans'], 0, 10000),
    );
  }
}

class RewardMail {
  RewardMail(
    this.id,
    this.title, {
    this.credits = 0,
    this.plans = 0,
    this.food = 0,
    this.gearKeys = 0,
    this.techKeys = 0,
    this.eggs = 0,
    this.claimed = false,
  });
  final String id, title;
  final int credits, plans, food, gearKeys, techKeys, eggs;
  bool claimed;
  String get summary => [
    if (credits > 0) '$credits C',
    if (plans > 0) '설계도 $plans',
    if (food > 0) '먹이 $food',
    if (gearKeys > 0) '장비 보급권 $gearKeys',
    if (techKeys > 0) '테크 보급권 $techKeys',
    if (eggs > 0) '펫 구조권 $eggs',
  ].join(' · ');
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'credits': credits,
    'plans': plans,
    'food': food,
    'gearKeys': gearKeys,
    'techKeys': techKeys,
    'eggs': eggs,
    'claimed': claimed,
  };
  static RewardMail? restore(dynamic v) {
    if (v is! Map ||
        v['id'] is! String ||
        v['title'] is! String ||
        (v['id'] as String).length > 160) {
      return null;
    }
    return RewardMail(
      v['id'],
      v['title'],
      credits: boundedInt(v['credits'], 0, 999999),
      plans: boundedInt(v['plans'], 0, 9999),
      food: boundedInt(v['food'], 0, 99999),
      gearKeys: boundedInt(v['gearKeys'], 0, 100),
      techKeys: boundedInt(v['techKeys'], 0, 100),
      eggs: boundedInt(v['eggs'], 0, 100),
      claimed: v['claimed'] == true,
    );
  }
}
