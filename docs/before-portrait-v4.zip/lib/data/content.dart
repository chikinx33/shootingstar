import 'package:flutter/material.dart';

@immutable
class ShipSpec {
  const ShipSpec({
    required this.name,
    required this.tagline,
    required this.detail,
    required this.color,
    required this.unlockCost,
    required this.health,
    required this.speed,
    required this.damage,
    required this.asset,
  });
  final String name, tagline, detail, asset;
  final Color color;
  final int unlockCost;
  final double health, speed, damage;
}

const ships = <ShipSpec>[
  ShipSpec(
    name: '오로라',
    tagline: '균형형 탐사 기체',
    detail: '견고한 선체와 안정적인 화력. 처음 항해하기에 적합합니다.',
    color: Color(0xFF60E7EF),
    unlockCost: 0,
    health: 120,
    speed: 200,
    damage: 1,
    asset: 'assets/art/survival_ship.png',
  ),
  ShipSpec(
    name: '벡터',
    tagline: '고속 요격 기체',
    detail: '빠르게 포위를 벗어나 강한 공격을 가하지만 선체가 가볍습니다.',
    color: Color(0xFFFFB768),
    unlockCost: 200,
    health: 90,
    speed: 245,
    damage: 1.2,
    asset: 'assets/art/shootingstar_scout.png',
  ),
  ShipSpec(
    name: '모노리스',
    tagline: '중장갑 순항 기체',
    detail: '느리지만 두꺼운 장갑과 강한 주포로 전선을 밀어냅니다.',
    color: Color(0xFFB9A1FF),
    unlockCost: 450,
    health: 175,
    speed: 165,
    damage: 1.15,
    asset: 'assets/art/shootingstar_bastion.png',
  ),
];

@immutable
class StageSpec {
  const StageSpec({
    required this.name,
    required this.subtitle,
    required this.description,
    required this.color,
    required this.duration,
    required this.difficulty,
  });
  final String name, subtitle, description, difficulty;
  final Color color;
  final int duration;
}

const stages = <StageSpec>[
  StageSpec(
    name: '잔광 외곽',
    subtitle: '01 / AFTERGLOW',
    description: '흩어진 정찰 군집 사이로 진입하세요. 마지막에 수문장이 출현합니다.',
    color: Color(0xFF60E7EF),
    duration: 600,
    difficulty: '보통',
  ),
  StageSpec(
    name: '적색 성운',
    subtitle: '02 / RED NEBULA',
    description: '빠른 돌격기와 탄막 편대가 밀려옵니다. 끊임없이 움직이세요.',
    color: Color(0xFFFF8D77),
    duration: 900,
    difficulty: '어려움',
  ),
  StageSpec(
    name: '공허의 왕관',
    subtitle: '03 / VOID CROWN',
    description: '정예 함대가 지키는 심연. 성장한 무기와 신중한 항로가 필요합니다.',
    color: Color(0xFFB9A1FF),
    duration: 900,
    difficulty: '극한',
  ),
];

@immutable
class EquipmentSpec {
  const EquipmentSpec(this.name, this.detail, this.color);
  final String name, detail;
  final Color color;
}

const equipmentOptions = <EquipmentSpec>[
  EquipmentSpec('보강 프레임', '최대 선체 +20% · 균형 잡힌 생존 장비', Color(0xFF60E7EF)),
  EquipmentSpec('과충전 코어', '피해 +20% · 최대 선체 −10%', Color(0xFFFFB768)),
  EquipmentSpec('회수 렌즈', '경험치 회수 범위 +70% · 이동 속도 +5%', Color(0xFFB9A1FF)),
];

const maxUpgradeLevel = 5;
int upgradeCost(int currentLevel) => 80 + currentLevel * 60;
