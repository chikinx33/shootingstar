class SurvivalSkill {
  const SurvivalSkill(
    this.id,
    this.name,
    this.description, {
    this.passive = false,
    this.partner,
    this.evolution,
  });
  final String id, name, description;
  final bool passive;
  final String? partner, evolution;
}

const survivalSkills = [
  SurvivalSkill(
    'gun',
    '펄스 블래스터',
    '가장 가까운 적을 전방위 자동 조준',
    partner: 'attack',
    evolution: '초신성 탄막',
  ),
  SurvivalSkill(
    'missile',
    '추적 로켓',
    '강한 적을 추적하는 범위 폭발',
    partner: 'area',
    evolution: '궤도 폭격',
  ),
  SurvivalSkill(
    'drone',
    '요격 드론',
    '주변 적에게 빠른 요격 사격',
    partner: 'cooldown',
    evolution: '쌍성 요격대',
  ),
  SurvivalSkill(
    'side',
    '광자 수레바퀴',
    '모든 방향으로 퍼지는 광자탄',
    partner: 'speed',
    evolution: '광자 폭풍',
  ),
  SurvivalSkill(
    'mine',
    '중력 지뢰',
    '추격하는 군집을 폭발로 제거',
    partner: 'hull',
    evolution: '중력 붕괴',
  ),
  SurvivalSkill(
    'trail',
    '플라스마 장판',
    '기체 주변에 지속 피해 영역 생성',
    partner: 'magnet',
    evolution: '항성 코로나',
  ),
  SurvivalSkill(
    'guardian',
    '궤도 수호자',
    '회전하는 위성이 적을 밀어내고 탄환 제거',
    partner: 'duration',
    evolution: '행성 방패',
  ),
  SurvivalSkill(
    'lightning',
    '이온 낙뢰',
    '무작위 적에게 즉시 연쇄 타격',
    partner: 'xp',
    evolution: '천둥 성운',
  ),
  SurvivalSkill('attack', '고밀도 탄약', '단계마다 모든 피해 +10%', passive: true),
  SurvivalSkill('area', '고출력 연료', '단계마다 폭발·장판 범위 +12%', passive: true),
  SurvivalSkill('cooldown', '에너지 큐브', '단계마다 무기 재사용 시간 −7%', passive: true),
  SurvivalSkill('speed', '추진 부스터', '단계마다 이동 속도 +8%', passive: true),
  SurvivalSkill('hull', '장갑 증폭기', '단계마다 기본 선체의 20% 추가·회복', passive: true),
  SurvivalSkill('magnet', '회수 자기장', '단계마다 경험치 회수 반경 +28', passive: true),
  SurvivalSkill('duration', '지속 전지', '단계마다 지뢰·장판 지속 시간 +20%', passive: true),
  SurvivalSkill('xp', '전술 기록기', '단계마다 경험치 획득 +8%', passive: true),
];

SurvivalSkill skillFor(String id) =>
    survivalSkills.firstWhere((s) => s.id == id);
