import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

import '../data/profile.dart';

class GameSound {
  GameSound(this.profile);
  final Profile profile;
  final List<AudioPlayer> _players = [];
  int _next = 0;
  bool _disposed = false;
  final Map<String, DateTime> _last = {};
  void play(String event) {
    if (_disposed || !profile.soundEnabled || profile.volume == 0) return;
    final now = DateTime.now();
    if (now.difference(_last[event] ?? DateTime(2000)).inMilliseconds <
        (event == 'shoot' ? 170 : 80)) {
      return;
    }
    _last[event] = now;
    if (_players.isEmpty) {
      _players.addAll(List.generate(4, (_) => AudioPlayer()));
    }
    final player = _players[_next++ % _players.length];
    unawaited(_play(player, event));
  }

  Future<void> _play(AudioPlayer player, String event) async {
    try {
      await player.play(
        AssetSource('audio/$event.wav'),
        volume: profile.volume * (event == 'shoot' ? .2 : .7),
      );
    } catch (_) {
      /* Browser audio may be unavailable. */
    }
  }

  void stop() {
    for (final player in _players) {
      unawaited(player.stop().catchError((Object _) {}));
    }
  }

  void dispose() {
    _disposed = true;
    for (final player in _players) {
      unawaited(player.dispose().catchError((Object _) {}));
    }
  }
}
