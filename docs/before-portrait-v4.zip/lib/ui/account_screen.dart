import 'package:flutter/material.dart';

import '../data/profile.dart';
import '../data/cloud_sync.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key, required this.profile});
  final Profile profile;
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  final user = TextEditingController(),
      password = TextEditingController(),
      name = TextEditingController(),
      recovery = TextEditingController();
  int mode = 0;
  String? error;
  CloudSync get online => widget.profile.online!;
  @override
  void dispose() {
    user.dispose();
    password.dispose();
    name.dispose();
    recovery.dispose();
    super.dispose();
  }

  Future<void> run(Future<void> Function() action) async {
    setState(() => error = null);
    try {
      await action();
    } catch (e) {
      if (mounted) {
        setState(() => error = e.toString().replaceFirst('Bad state: ', ''));
      }
    }
  }

  Future<void> submit() async {
    if (!RegExp(r'^[a-z0-9_]{4,24}$')
        .hasMatch(user.text.trim().toLowerCase())) {
      setState(() => error = '아이디는 영문·숫자·밑줄 4~24자로 입력하세요.');
      return;
    }
    if (password.text.length < 12 || password.text.length > 128) {
      setState(() => error = '비밀번호는 12~128자로 입력하세요.');
      return;
    }
    if (mode == 1 &&
        (name.text.trim().isEmpty || name.text.trim().length > 16)) {
      setState(() => error = '닉네임은 1~16자로 입력하세요.');
      return;
    }
    await run(
      () => online.login(
        user.text.trim().toLowerCase(),
        password.text,
        nickname: mode == 1 ? name.text.trim() : null,
        recovery: mode == 2 ? recovery.text : null,
      ),
    );
    password.clear();
    recovery.clear();
  }

  Future<void> resolve(bool cloud) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(cloud ? '서버 진행을 불러올까요?' : '이 기기 진행을 저장할까요?'),
        content: const Text('선택한 진행으로 동기화합니다. 선택 전 두 진행은 이 기기에 백업됩니다.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c, false),
            child: const Text('취소'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, true),
            child: const Text('선택한 진행 사용'),
          ),
        ],
      ),
    );
    if (yes == true) await run(() => online.resolve(useCloud: cloud));
  }

  String summary(dynamic value) => value is Map
      ? '출격 ${value['runs'] ?? 0}회 · ${value['credits'] ?? 0} 크레딧 · 장비 ${(value['content']?['inventory'] as List?)?.length ?? 0}개'
      : '저장 없음';
  @override
  Widget build(BuildContext context) {
    if (widget.profile.online == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('계정')),
        body: const Center(child: Text('온라인 서비스를 준비하고 있습니다.')),
      );
    }
    return ListenableBuilder(
      listenable: online,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('계정 · 클라우드 저장')),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                const Icon(Icons.cloud_done_outlined, size: 48),
                const SizedBox(height: 16),
                Text(online.status, textAlign: TextAlign.center),
                const SizedBox(height: 20),
                if (online.busy) const LinearProgressIndicator(),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: Text(
                      error!,
                      style: const TextStyle(color: Colors.orange),
                    ),
                  ),
                if (online.signedIn) ...[
                  Text(
                    online.nickname,
                    style: const TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '@${online.account?['username']} · 저장 버전 ${online.revision}',
                  ),
                  if (online.updatedAt > 0)
                    Text(
                      '서버 저장: ${DateTime.fromMillisecondsSinceEpoch(online.updatedAt * 1000).toLocal()}',
                    ),
                  const SizedBox(height: 16),
                  if (online.recoveryCode.isNotEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              '복구 코드를 안전하게 보관하세요',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            const Text(
                              '비밀번호 분실 시 필요합니다. 이 화면에서 한 번만 표시되며 다른 사람에게 알려주지 마세요.',
                            ),
                            SelectableText(online.recoveryCode),
                            TextButton(
                              onPressed: () {
                                online.recoveryCode = '';
                                setState(() {});
                              },
                              child: const Text('별도로 보관했습니다'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (online.conflict != null)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            const Text(
                              '다른 기기의 진행과 충돌했습니다',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text('서버: ${summary(online.conflict!['profile'])}'),
                            Text(
                              '이 기기: ${summary(widget.profile.exportProgress())}',
                            ),
                            OutlinedButton(
                              onPressed: online.busy
                                  ? null
                                  : () => resolve(true),
                              child: const Text('서버 진행 사용'),
                            ),
                            OutlinedButton(
                              onPressed: online.busy
                                  ? null
                                  : () => resolve(false),
                              child: const Text('이 기기 진행 저장'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  FilledButton(
                    onPressed: online.busy ? null : () => run(online.sync),
                    child: const Text('지금 동기화'),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    '장비·펫·테크·시즌·우편을 함께 저장합니다. 다른 기기에서 같은 계정으로 로그인하면 이어서 플레이할 수 있습니다. 전투 중에는 기기에 저장하고 귀환 후 동기화합니다.',
                  ),
                  const SizedBox(height: 20),
                  OutlinedButton(
                    onPressed: online.busy
                        ? null
                        : () => run(() => online.logout()),
                    child: const Text('로그아웃 · 게스트로 돌아가기'),
                  ),
                  TextButton(
                    onPressed: online.busy
                        ? null
                        : () => run(() => online.logout(all: true)),
                    child: const Text('모든 기기 로그아웃'),
                  ),
                ] else ...[
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, label: Text('로그인')),
                      ButtonSegment(value: 1, label: Text('가입')),
                      ButtonSegment(value: 2, label: Text('복구')),
                    ],
                    selected: {mode},
                    onSelectionChanged: online.busy
                        ? null
                        : (v) => setState(() => mode = v.first),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    mode == 1
                        ? '현재 기기의 진행으로 계정을 만듭니다.'
                        : mode == 2
                        ? '복구 코드로 새 비밀번호를 설정합니다. 기존 로그인은 모두 해제됩니다.'
                        : '로그인하면 계정의 진행을 불러옵니다. 현재 진행은 이 기기에 백업됩니다.',
                  ),
                  TextField(
                    controller: user,
                    enabled: !online.busy,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: '아이디',
                      hintText: '영문·숫자·밑줄 4~24자',
                    ),
                  ),
                  if (mode == 1)
                    TextField(
                      controller: name,
                      enabled: !online.busy,
                      maxLength: 16,
                      decoration: const InputDecoration(labelText: '닉네임'),
                    ),
                  if (mode == 2)
                    TextField(
                      controller: recovery,
                      enabled: !online.busy,
                      autocorrect: false,
                      decoration: const InputDecoration(
                        labelText: '48자리 복구 코드',
                      ),
                    ),
                  TextField(
                    controller: password,
                    enabled: !online.busy,
                    obscureText: true,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: InputDecoration(
                      labelText: mode == 2 ? '새 비밀번호' : '비밀번호',
                      helperText: '12~128자',
                    ),
                    onSubmitted: (_) => online.busy ? null : submit(),
                  ),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: online.busy || !online.ready ? null : submit,
                    child: Text(
                      mode == 1
                          ? '현재 진행으로 계정 만들기'
                          : mode == 2
                          ? '계정 복구'
                          : '로그인',
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    '가입하지 않아도 기기 저장으로 플레이할 수 있습니다. 온라인 길드와 기기 간 저장은 계정이 필요합니다.',
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
