import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../data/profile.dart';
import '../data/content_catalog.dart';
import '../data/content_systems.dart';
import '../main.dart';
import 'components.dart';
import 'guild_screen.dart';

class AtlasIcon extends StatefulWidget {
  const AtlasIcon({
    super.key,
    required this.index,
    this.tech = false,
    this.size = 64,
  });
  final int index;
  final bool tech;
  final double size;
  @override
  State<AtlasIcon> createState() => _AtlasIconState();
}

class _AtlasIconState extends State<AtlasIcon> {
  static final Map<bool, Future<ui.Image>> _cache = {};
  Future<ui.Image> get image => _cache.putIfAbsent(widget.tech, () async {
    final bytes = await rootBundle.load(
      'assets/art/content_${widget.tech ? 'tech' : 'equipment'}.png',
    );
    final codec = await ui.instantiateImageCodec(bytes.buffer.asUint8List());
    final frame = await codec.getNextFrame();
    codec.dispose();
    return frame.image;
  });
  @override
  Widget build(BuildContext context) => SizedBox(
    width: widget.size,
    height: widget.size,
    child: FutureBuilder<ui.Image>(
      future: image,
      builder: (c, s) => s.hasData
          ? CustomPaint(
              painter: _AtlasPainter(
                s.data!,
                widget.index,
                widget.tech ? 4 : 3,
              ),
            )
          : const SizedBox(),
    ),
  );
}

class _AtlasPainter extends CustomPainter {
  _AtlasPainter(this.image, this.index, this.cols);
  final ui.Image image;
  final int index, cols;
  @override
  void paint(Canvas c, Size s) {
    final w = image.width / cols, h = image.height / 2;
    c.drawImageRect(
      image,
      Rect.fromLTWH(index % cols * w, index ~/ cols * h, w, h),
      Offset.zero & s,
      Paint()..filterQuality = FilterQuality.medium,
    );
  }

  @override
  bool shouldRepaint(_AtlasPainter old) =>
      old.image != image || old.index != index;
}

class ContentHub extends StatefulWidget {
  const ContentHub({super.key, required this.profile, this.initialPage = 0});
  final Profile profile;
  final int initialPage;
  @override
  State<ContentHub> createState() => _ContentHubState();
}

class _ContentHubState extends State<ContentHub> {
  late int page = widget.initialPage;
  int filter = -1;
  bool bestFirst = true;
  Profile get p => widget.profile;
  Timer? timer;
  static const colors = [
    Colors.grey,
    Colors.greenAccent,
    Colors.lightBlueAccent,
    Colors.purpleAccent,
    Colors.amber,
    Colors.redAccent,
  ];
  @override
  void initState() {
    super.initState();
    p.addListener(refresh);
    timer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (p.refreshContentClock(DateTime.now())) {
        p.contentChanged();
      } else {
        refresh();
      }
    });
  }

  void refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    timer?.cancel();
    p.removeListener(refresh);
    super.dispose();
  }

  void act(bool Function() action) {
    final done = action();
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          done
              ? (p.lastLoot.isEmpty ? '적용했습니다.' : p.lastLoot)
              : '재료·크레딧·장착 슬롯을 확인하세요.',
        ),
        duration: const Duration(seconds: 2),
      ),
    );
    p.lastLoot = '';
  }

  Widget title(String a, String b) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          a,
          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
        ),
        gap(6),
        Text(b, style: const TextStyle(color: muted)),
      ],
    ),
  );
  Widget card(Widget child) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Surface(child: child),
  );
  Widget button(String label, bool allowed, bool Function() action) =>
      FilledButton(
        onPressed: allowed ? () => act(action) : null,
        child: Text(label),
      );
  @override
  Widget build(BuildContext context) => Column(
    children: [
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Row(
          children: [
            for (int i = 0; i < 6; i++)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(['장비', '펫', '테크', '보급', '시즌', '길드'][i]),
                  selected: page == i,
                  onSelected: (_) {
                    if (i == 5) {
                      Navigator.push(
                        context,
                        MaterialPageRoute<void>(
                          builder: (_) => GuildScreen(profile: p),
                        ),
                      );
                    } else {
                      p.refreshContentClock(DateTime.now());
                      setState(() => page = i);
                    }
                  },
                ),
              ),
          ],
        ),
      ),
      Expanded(
        child: ListView(
          key: ValueKey(page),
          padding: const EdgeInsets.all(16),
          children: switch (page) {
            0 => gear(),
            1 => pets(),
            2 => tech(),
            3 => supplies(),
            _ => season(),
          },
        ),
      ),
    ],
  );
  List<Widget> gear() {
    final items =
        p.inventory
            .where((g) => filter < 0 || g.definition.slot == filter)
            .toList()
          ..sort(
            (a, b) => bestFirst
                ? (b.rank * 100 + b.level).compareTo(a.rank * 100 + a.level)
                : b.id.compareTo(a.id),
          );
    return [
      title(
        '나의 장비',
        '화력 +${(p.gearDamage * 100).round()}% · 선체 +${(p.gearHull * 100).round()}% · 설계도 ${p.blueprints}',
      ),
      card(
        Column(
          children: [
            const Text(
              '출격 장착 · 6슬롯',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            gap(8),
            LayoutBuilder(
              builder: (c, constraint) => Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (int i = 0; i < 6; i++)
                    SizedBox(
                      width: (constraint.maxWidth - 16) / 3,
                      child: InkWell(
                        onTap: () => details(p.gearAt(i)),
                        child: Column(
                          children: [
                            AtlasIcon(index: i, size: 62),
                            Text(
                              slotNames[i],
                              style: const TextStyle(
                                color: muted,
                                fontSize: 11,
                              ),
                            ),
                            Text(
                              '${qualityNames[p.gearAt(i).rank]} +${p.gearAt(i).level}',
                              style: TextStyle(color: colors[p.gearAt(i).rank]),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
      const Text(
        '동일 장비·등급 3개를 합성합니다. 잠금·장착·강화된 장비는 재료에서 제외됩니다. 강화 재료는 초기화 시 전액 반환됩니다.',
        style: TextStyle(color: muted, fontSize: 12),
      ),
      gap(),
      Row(
        children: [
          Expanded(
            child: Text(
              '인벤토리 ${p.inventory.length}/240',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          TextButton(
            onPressed: () => setState(() => bestFirst = !bestFirst),
            child: Text(bestFirst ? '등급순' : '최신순'),
          ),
        ],
      ),
      Wrap(
        spacing: 6,
        children: [
          for (int i = -1; i < 6; i++)
            ChoiceChip(
              label: Text(i < 0 ? '전체' : slotNames[i]),
              selected: filter == i,
              onSelected: (_) => setState(() => filter = i),
            ),
        ],
      ),
      gap(),
      for (final g in items)
        card(
          InkWell(
            onTap: () => details(g),
            child: Row(
              children: [
                AtlasIcon(index: g.definition.slot, size: 58),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        g.definition.name,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${qualityNames[g.rank]} · Lv.${g.level} · #${g.id}',
                        style: TextStyle(color: colors[g.rank]),
                      ),
                      Text(
                        '${p.equippedGear.contains(g.id) ? '장착 중  ' : ''}${g.locked ? '보호 잠금' : ''}',
                        style: const TextStyle(fontSize: 11, color: cyan),
                      ),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
        ),
      for (int i = 0; i < 6; i++)
        if (p.gearCopies[i] > 0)
          button(
            '기존 ${slotNames[i]} 부품 ${p.gearCopies[i]}개 · 1개 변환',
            true,
            () => p.convertLegacyPart(i),
          ),
    ];
  }

  Future<void> details(GearItem g) async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (c, update) {
          final materials = p.mergeMaterials(g);
          void change(bool Function() action) {
            act(action);
            update(() {});
          }

          return AlertDialog(
            title: Text(g.definition.name),
            content: SizedBox(
              width: 380,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: AtlasIcon(index: g.definition.slot, size: 110),
                    ),
                    Text(
                      '${qualityNames[g.rank]} · Lv.${g.level}/${20 + g.rank * 10} · #${g.id}',
                      style: TextStyle(color: colors[g.rank]),
                    ),
                    gap(8),
                    Text(g.definition.perk),
                    gap(),
                    Text('강화: ${p.itemUpgradeCost(g)} C + 설계도 1'),
                    Text('보유 ${p.credits} C · 설계도 ${p.blueprints}'),
                    Wrap(
                      spacing: 6,
                      children: [
                        FilledButton(
                          onPressed: p.equippedGear.contains(g.id)
                              ? null
                              : () => change(() => p.equipItem(g.id)),
                          child: Text(
                            p.equippedGear.contains(g.id) ? '장착 중' : '장착',
                          ),
                        ),
                        OutlinedButton(
                          onPressed: () => change(() => p.lockItem(g.id)),
                          child: Text(g.locked ? '잠금 해제' : '보호 잠금'),
                        ),
                        FilledButton(
                          onPressed:
                              g.level < 20 + g.rank * 10 &&
                                  p.credits >= p.itemUpgradeCost(g) &&
                                  p.blueprints > 0
                              ? () => change(() => p.enhanceItem(g.id))
                              : null,
                          child: const Text('장비 강화'),
                        ),
                        TextButton(
                          onPressed: g.level > 0
                              ? () => change(() => p.resetItem(g.id))
                              : null,
                          child: Text(
                            '초기화 · ${g.spentCredits} C / 설계도 ${g.spentPlans} 반환',
                          ),
                        ),
                      ],
                    ),
                    const Divider(),
                    Text(
                      g.rank >= 5
                          ? '최고 등급입니다.'
                          : '합성 → ${qualityNames[(g.rank + 1).clamp(0, 5)]}',
                    ),
                    Text(
                      '소모 재료: ${materials.isEmpty ? '없음' : materials.map((m) => '#${m.id} ${m.definition.name}').join(', ')}',
                      style: const TextStyle(color: muted, fontSize: 12),
                    ),
                    FilledButton(
                      onPressed: g.rank < 5 && materials.length == 2
                          ? () async {
                              final yes = await showDialog<bool>(
                                context: c,
                                builder: (confirm) => AlertDialog(
                                  title: const Text('합성 재료 확인'),
                                  content: Text(
                                    '#${g.id}의 등급이 올라갑니다.\n${materials.map((m) => '#${m.id}').join(' + ')} 두 장비는 소모됩니다.',
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () =>
                                          Navigator.pop(confirm, false),
                                      child: const Text('취소'),
                                    ),
                                    FilledButton(
                                      onPressed: () =>
                                          Navigator.pop(confirm, true),
                                      child: const Text('합성 확정'),
                                    ),
                                  ],
                                ),
                              );
                              if (yes == true && mounted) {
                                change(() => p.mergeItem(g.id));
                              }
                            }
                          : null,
                      child: const Text('동일 장비 3개 합성'),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(c),
                child: const Text('닫기'),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> pets() => [
    title('동행 펫', '출전 1마리 + 보조 2마리 · 먹이 ${p.petFood} · 구조권 ${p.petEggs}'),
    const Text(
      '동행 펫은 적과 함께 싸웁니다. 쓰러진 펫 근처에서 8초를 지키면 부활합니다. 보조 효과: 루미 쿨다운 −4%, 미오 회수 +10%, 볼트 피해 −5%.',
      style: TextStyle(color: muted, fontSize: 12),
    ),
    gap(),
    for (int i = 0; i < 3; i++)
      card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                ColorFiltered(
                  colorFilter: ColorFilter.mode(
                    [
                      Colors.transparent,
                      Colors.teal.withValues(alpha: .25),
                      Colors.purple.withValues(alpha: .25),
                    ][i],
                    BlendMode.srcATop,
                  ),
                  child: Image.asset(
                    'assets/art/content_pet.png',
                    width: 90,
                    height: 110,
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        petNames[i],
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        p.petLevels[i] == 0
                            ? '미구조'
                            : 'Lv.${p.petLevels[i]} · ${qualityNames[p.petRanks[i]]}',
                        style: const TextStyle(color: cyan),
                      ),
                      Text(
                        petDescriptions[i],
                        style: const TextStyle(fontSize: 12, color: muted),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (p.petLevels[i] > 0) ...[
              Text('유전자 ${p.petShards[i]} / ${3 * (p.petRanks[i] + 1)}'),
              Wrap(
                spacing: 8,
                children: [
                  button(
                    p.activePet == i ? '출전 중' : '출전',
                    p.activePet != i,
                    () => p.deployPet(i),
                  ),
                  button(
                    p.assistingPets.contains(i) ? '보조 해제' : '보조 배치',
                    p.activePet != i,
                    () => p.assistPet(i),
                  ),
                  button(
                    '먹이 ${p.petLevels[i] * 10} · 육성',
                    p.petFood >= p.petLevels[i] * 10 &&
                        p.petLevels[i] < 20 + p.petRanks[i] * 10,
                    () => p.feedPet(i),
                  ),
                  button(
                    '각성',
                    p.petRanks[i] < 5 &&
                        p.petShards[i] >= 3 * (p.petRanks[i] + 1),
                    () => p.evolvePet(i),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    button('펫 구조 · 구조권 1', p.petEggs > 0, p.rescuePet),
    const Text(
      '루미 → 미오 → 볼트 순서로 구조합니다. 이미 구조한 펫은 각성 유전자 1개로 전환됩니다.',
      style: TextStyle(color: muted, fontSize: 12),
    ),
  ];
  List<Widget> tech() => [
    title(
      '테크 연구소',
      '공격 ${p.equippedTech.where((t) => t < 4).length}/3 · 방어 ${p.equippedTech.where((t) => t >= 4).length}/3',
    ),
    const Text(
      '해당 무기를 획득하면 부품 효과가 적용됩니다. 등급마다 무기 피해 +5%, 희귀부터 고유 효과가 해금됩니다. 동일 등급 3개로 다음 등급을 만듭니다.',
      style: TextStyle(color: muted, fontSize: 12),
    ),
    gap(),
    for (int i = 0; i < 8; i++)
      card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                AtlasIcon(index: i, tech: true, size: 68),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        techNames[i],
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 17,
                        ),
                      ),
                      Text(
                        '${i < 4 ? '공격' : '방어'} · ${p.techRank(i) < 0 ? '미보유' : qualityNames[p.techRank(i)]}',
                        style: TextStyle(
                          color: p.techRank(i) < 0
                              ? muted
                              : colors[p.techRank(i)],
                        ),
                      ),
                      Text(
                        techPerks[i],
                        style: TextStyle(
                          fontSize: 12,
                          color: p.techRank(i) >= 2 ? cyan : muted,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            gap(8),
            Text(
              [
                for (int r = 0; r < 6; r++)
                  if (p.techStock[i][r] > 0)
                    '${qualityNames[r]} ${p.techStock[i][r]}개',
              ].join(' · '),
              style: const TextStyle(fontSize: 12),
            ),
            Wrap(
              spacing: 6,
              children: [
                button(
                  p.equippedTech.contains(i) ? '부품 해제' : '부품 장착',
                  p.techRank(i) >= 0 &&
                      (p.equippedTech.contains(i) ||
                          p.equippedTech
                                  .where((t) => (t < 4) == (i < 4))
                                  .length <
                              3),
                  () => p.equipTech(i),
                ),
                for (int r = 0; r < 5; r++)
                  if (p.techStock[i][r] >= 3)
                    button(
                      '${qualityNames[r]} 3개 합성',
                      true,
                      () => p.mergeTech(i, r),
                    ),
              ],
            ),
          ],
        ),
      ),
  ];
  List<Widget> supplies() => [
    title('함대 보급', '출격 · 일일 임무 · 시즌 · 길드에서 보급권을 얻으세요.'),
    card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '장비 보급',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const AtlasIcon(index: 0, size: 100),
          Text(
            '보급권 ${p.gearKeys} · 10회째 엘리트 보급까지 ${10 - p.supplySerial % 10}회',
          ),
          const Text(
            '12종 순환 지급 · 매 3회 우수 · 매 10회 엘리트. 확률형 유료 상품이 없는 보급입니다.',
            style: TextStyle(color: muted, fontSize: 12),
          ),
          button(
            '장비 보급 열기',
            p.gearKeys > 0 && p.inventory.length < 240,
            p.openGearSupply,
          ),
        ],
      ),
    ),
    card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '테크 보급',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const AtlasIcon(index: 2, tech: true, size: 90),
          Text('보급권 ${p.techKeys} · 8종 순환 지급'),
          button('테크 보급 열기', p.techKeys > 0, p.openTechSupply),
        ],
      ),
    ),
    card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '펫 구조 신호',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Text('구조권 ${p.petEggs} · 중복은 각성 유전자로 전환'),
          button('펫 구조하기', p.petEggs > 0, p.rescuePet),
        ],
      ),
    ),
    title('일일 교환소', '전투 크레딧으로 교환 · 품목별 매일 3회'),
    for (final offer in [
      ('food', '먹이 30', 60),
      ('plans', '설계도 3', 100),
      ('gear', '장비 보급권 1', 180),
      ('tech', '테크 보급권 1', 180),
      ('egg', '펫 구조권 1', 200),
    ])
      card(
        Row(
          children: [
            Expanded(
              child: Text('${offer.$2}\n오늘 ${p.shopCounts[offer.$1] ?? 0}/3'),
            ),
            button(
              '${offer.$3} C',
              p.credits >= offer.$3 && (p.shopCounts[offer.$1] ?? 0) < 3,
              () => p.buyMaterial(offer.$1),
            ),
          ],
        ),
      ),
  ];
  List<Widget> season() => [
    title(
      '항성 원정 · ${p.seasonKey}',
      '${p.seasonDaysLeft(DateTime.now())}일 남음 · 한국 시간 매월 1일 새 시즌',
    ),
    card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '시즌 Lv.${(p.seasonXp ~/ 100).clamp(0, 20)} / 20',
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
          ),
          gap(8),
          LinearProgressIndicator(value: (p.seasonXp / 2000).clamp(0, 1)),
          gap(8),
          Text('${p.seasonXp} XP · 출격과 일일 임무로 성장'),
          const Text(
            '이전 시즌에서 달성한 미수령 보상은 우편으로 보관됩니다.',
            style: TextStyle(color: muted, fontSize: 12),
          ),
        ],
      ),
    ),
    const Text(
      '오늘의 임무',
      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
    ),
    gap(8),
    for (int i = 0; i < 3; i++)
      card(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(ContentSystems.dailyNames[i]),
            Text(
              '${p.dailyProgress(i)} / ${ContentSystems.dailyTargets[i]} · 시즌 XP 50 + 50 C + 먹이 10 + 보급권',
            ),
            button(
              p.dailyClaims.contains(i) ? '수령 완료' : '일일 보상 수령',
              !p.dailyClaims.contains(i) &&
                  p.dailyProgress(i) >= ContentSystems.dailyTargets[i],
              () => p.claimDaily(i),
            ),
          ],
        ),
      ),
    card(
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '자동 순찰',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Text('${p.patrolMinutes(DateTime.now())}분 누적 / 최대 8시간'),
          const Text('30분마다 20 C · 1시간마다 설계도 1 + 먹이 5'),
          button(
            '순찰 보상 회수',
            p.patrolMinutes(DateTime.now()) >= 30,
            () => p.claimPatrol(DateTime.now()),
          ),
        ],
      ),
    ),
    title('보상 우편', '미수령 ${p.mail.where((m) => !m.claimed).length}건'),
    if (p.mail.isEmpty)
      const Text('시즌 이월·길드 보상이 이곳에 도착합니다.', style: TextStyle(color: muted)),
    for (final m in p.mail.reversed)
      if (!m.claimed)
        card(
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(m.title),
              Text(
                m.summary,
                style: const TextStyle(color: muted, fontSize: 12),
              ),
              button('우편 보상 받기', true, () => p.claimMail(m.id)),
            ],
          ),
        ),
    title('시즌 보상 트랙', '모든 20단계 무료 · 단계마다 100 XP'),
    for (int t = 1; t <= 20; t++)
      card(
        Row(
          children: [
            CircleAvatar(
              backgroundColor: p.seasonXp >= t * 100 ? cyan : Colors.blueGrey,
              child: Text('$t', style: const TextStyle(color: Colors.black)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$t단계 · ${t * 100} XP'),
                  Text(
                    p.seasonReward(p.seasonKey, t).summary,
                    style: const TextStyle(fontSize: 12, color: muted),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: p.seasonXp >= t * 100 && !p.seasonClaims.contains(t)
                  ? () => act(() => p.claimSeason(t))
                  : null,
              child: Text(p.seasonClaims.contains(t) ? '완료' : '받기'),
            ),
          ],
        ),
      ),
  ];
}
