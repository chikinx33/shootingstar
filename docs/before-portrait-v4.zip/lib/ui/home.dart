import 'package:flutter/material.dart';

import '../data/content.dart';
import '../data/profile.dart';
import '../main.dart';
import 'components.dart';
import 'battle.dart';
import 'account_screen.dart';
import 'survival_meta.dart';
import 'content_hub.dart';
import '../data/guild_client.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.profile});
  final Profile profile;
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  bool _launching = false;
  Profile get p => widget.profile;
  @override
  void initState() {
    super.initState();
    p.addListener(_refresh);
    p.online?.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    p.removeListener(_refresh);
    p.online?.removeListener(_refresh);
    super.dispose();
  }

  Future<void> _launch({bool training = false, bool challenge = false}) async {
    if (_launching) return;
    if (p.online?.busy == true) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('계정 동기화가 끝난 뒤 출격해 주세요.')));
      return;
    }
    _launching = true;
    if (p.online != null) p.online!.inBattle = true;
    try {
      if (!p.onboarded) {
        await showGuide(context, p.finishOnboarding);
        if (!mounted) return;
      }
      final toHangar = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(
          builder: (_) => BattleScreen(
            profile: p,
            training: training,
            challenge: challenge,
          ),
        ),
      );
      if (mounted && toHangar == true) setState(() => tab = 2);
      if (p.guildToken.isNotEmpty && p.guildReports.isNotEmpty) {
        try {
          await GuildClient(p).syncReports();
        } catch (_) {
          /* Retained for retry in guild screen. */
        }
      }
    } finally {
      _launching = false;
      if (p.online != null) {
        p.online!.inBattle = false;
        p.online!.sync();
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1220),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 20,
                ),
                child: Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        border: Border.all(color: cyan),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: const Icon(
                        Icons.auto_awesome,
                        size: 20,
                        color: cyan,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'SHOOTINGSTAR',
                            style: TextStyle(
                              fontSize: 13,
                              letterSpacing: 2.7,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          Text(
                            '군집 생존 · SURVIVOR',
                            style: TextStyle(color: muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    const Icon(
                      Icons.hexagon_outlined,
                      color: Color(0xFFFFBD7A),
                      size: 19,
                    ),
                    const SizedBox(width: 7),
                    Text(
                      '${p.credits}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: '계정 · ${p.online?.status ?? "게스트"}',
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AccountScreen(profile: p),
                        ),
                      ),
                      icon: Icon(
                        p.online?.signedIn == true
                            ? Icons.cloud_done_outlined
                            : Icons.person_outline,
                        size: 21,
                      ),
                    ),
                    IconButton(
                      tooltip: '설정',
                      onPressed: () => _settings(context),
                      icon: const Icon(Icons.tune, size: 21),
                    ),
                  ],
                ),
              ),
              if (p.online?.conflict != null)
                MaterialBanner(
                  content: const Text('다른 기기의 진행과 충돌했습니다. 저장할 진행을 선택하세요.'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AccountScreen(profile: p),
                        ),
                      ),
                      child: const Text('진행 선택'),
                    ),
                  ],
                ),
              Expanded(
                child: tab == 0
                    ? _bridge()
                    : tab == 1
                    ? _hangar()
                    : tab == 2
                    ? ContentHub(profile: p)
                    : SurvivalMeta(
                        profile: p,
                        section: tab,
                        onChallenge: (i) {
                          p.selectStage(i);
                          _launch(challenge: true);
                        },
                      ),
              ),
              if (p.saveError != null)
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    p.saveError!,
                    style: const TextStyle(color: Colors.orange),
                  ),
                ),
              NavigationBar(
                height: 66,
                selectedIndex: tab,
                onDestinationSelected: (i) => setState(() => tab = i),
                backgroundColor: ink,
                destinations: const [
                  NavigationDestination(icon: Icon(Icons.radar), label: '출격'),
                  NavigationDestination(
                    icon: Icon(Icons.rocket_launch_outlined),
                    label: '격납고',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.inventory_2_outlined),
                    label: '성장',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.emoji_events_outlined),
                    label: '도전',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.auto_stories_outlined),
                    label: '도감',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    ),
  );
  Widget _bridge() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
    child: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 640),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(22),
              child: SizedBox(
                height: 245,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.asset(
                      'assets/art/survival_terrain.png',
                      fit: BoxFit.cover,
                    ),
                    Container(color: ink.withValues(alpha: .4)),
                    Positioned(
                      left: 16,
                      top: 18,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Eyebrow('SURVIVE THE SWARM'),
                          gap(8),
                          const Text(
                            '끝없는 군집.\n나만의 진화.',
                            style: TextStyle(
                              fontSize: 27,
                              height: 1.2,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          gap(8),
                          const Text(
                            '6 무기 × 6 보조 · 조합 생존',
                            style: TextStyle(color: cyan, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      right: 25,
                      bottom: 14,
                      child: Image.asset(
                        'assets/art/survival_ship.png',
                        height: 145,
                      ),
                    ),
                    Positioned(
                      left: 28,
                      bottom: 18,
                      child: Image.asset(
                        'assets/art/survival_enemy.png',
                        height: 54,
                      ),
                    ),
                    Positioned(
                      left: 100,
                      bottom: 35,
                      child: Image.asset(
                        'assets/art/survival_enemy.png',
                        height: 43,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            gap(18),
            _missions(),
            gap(16),
            Surface(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '성장과 원정 · 시즌 Lv.${(p.seasonXp ~/ 100).clamp(0, 20)}',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  gap(8),
                  Text(
                    '장비 ${p.inventory.length}개 · 테크 ${p.equippedTech.length}/6 · 미수령 우편 ${p.mail.where((m) => !m.claimed).length}건',
                    style: const TextStyle(color: muted),
                  ),
                  Wrap(
                    spacing: 8,
                    children: [
                      FilledButton(
                        onPressed: () => setState(() => tab = 2),
                        child: const Text('장비 · 펫 · 테크 성장'),
                      ),
                      OutlinedButton(
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute<void>(
                            builder: (_) => Scaffold(
                              appBar: AppBar(title: const Text('시즌 원정')),
                              body: ContentHub(profile: p, initialPage: 4),
                            ),
                          ),
                        ),
                        child: const Text('시즌 보상 · 순찰'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ),
  );
  Widget _missions() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Eyebrow('MAIN CHAPTER'),
      gap(8),
      const Text(
        '챕터 돌파',
        style: TextStyle(
          fontSize: 24,
          fontWeight: FontWeight.w800,
          letterSpacing: -.5,
        ),
      ),
      gap(6),
      const Text(
        '경험치 회수 → 스킬 조합 → 보스 격파 → 장비 성장',
        style: TextStyle(color: muted, fontSize: 13),
      ),
      gap(22),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          key: const Key('launch'),
          onPressed: _launch,
          icon: const Icon(Icons.arrow_upward, size: 19),
          label: Text('${stages[p.selectedStage].name} · 출격'),
        ),
      ),
      gap(16),
      for (int i = 0; i < stages.length; i++)
        Padding(padding: const EdgeInsets.only(bottom: 10), child: _stage(i)),
      gap(10),
      Surface(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              Icons.rocket_launch,
              color: ships[p.selectedShip].color,
              size: 23,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    ships[p.selectedShip].name,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    equipmentOptions[p.equipment].name,
                    style: const TextStyle(fontSize: 11, color: muted),
                  ),
                ],
              ),
            ),
            TextButton(
              onPressed: () => setState(() => tab = 1),
              child: const Text('기체 변경'),
            ),
          ],
        ),
      ),
      gap(16),
      gap(8),
      Row(
        children: [
          Expanded(
            child: TextButton.icon(
              onPressed: () => _launch(training: true),
              icon: const Icon(Icons.sports_esports_outlined, size: 18),
              label: const Text('45초 훈련'),
            ),
          ),
          TextButton(
            onPressed: () => showGuide(context, () {}),
            child: const Text('비행 가이드'),
          ),
        ],
      ),
      gap(12),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Stat('${p.runs}', '완료한 출격'),
          Stat('${p.bestKills}', '최고 격파'),
          Stat('${p.clearedStages.length} / 3', '정복한 항로'),
        ],
      ),
      gap(18),
    ],
  );
  Widget _stage(int i) {
    final s = stages[i];
    final unlocked = p.canStage(i);
    final active = p.selectedStage == i;
    return Semantics(
      button: true,
      selected: active,
      label: '${s.name} ${unlocked ? '항로 선택' : '잠김'}',
      child: InkWell(
        onTap: unlocked ? () => p.selectStage(i) : null,
        borderRadius: BorderRadius.circular(18),
        child: Surface(
          active: active,
          padding: const EdgeInsets.all(17),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 48,
                decoration: BoxDecoration(
                  color: s.color.withValues(alpha: unlocked ? 0.1 : 0.04),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  unlocked
                      ? (i == 0
                            ? Icons.blur_circular
                            : i == 1
                            ? Icons.flare
                            : Icons.brightness_2)
                      : Icons.lock_outline,
                  color: unlocked ? s.color : muted,
                ),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Eyebrow(s.subtitle, color: unlocked ? s.color : muted),
                    gap(4),
                    Text(
                      s.name,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        color: unlocked ? Colors.white : muted,
                      ),
                    ),
                    gap(3),
                    Text(
                      unlocked
                          ? '${s.duration ~/ 60}분 ${s.duration % 60}초  /  ${s.difficulty}'
                          : '이전 항로 클리어 시 개방',
                      style: const TextStyle(fontSize: 11, color: muted),
                    ),
                  ],
                ),
              ),
              if (p.clearedStages.contains(i))
                const Icon(Icons.check_circle_outline, color: cyan, size: 20)
              else
                Icon(
                  active ? Icons.radio_button_checked : Icons.chevron_right,
                  color: active ? cyan : muted,
                  size: 20,
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hangar() => SingleChildScrollView(
    padding: const EdgeInsets.fromLTRB(24, 4, 24, 28),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Eyebrow('HANGAR / MAKE IT YOURS'),
        gap(8),
        const Text(
          '당신만의 비행을 설계하세요',
          style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
        ),
        gap(8),
        const Text(
          '출격에서 얻은 크레딧으로 기체와 시스템을 강화합니다.',
          style: TextStyle(color: muted),
        ),
        gap(24),
        LayoutBuilder(
          builder: (context, c) => Wrap(
            spacing: 14,
            runSpacing: 14,
            children: [
              for (int i = 0; i < ships.length; i++)
                SizedBox(
                  width: c.maxWidth > 760 ? (c.maxWidth - 28) / 3 : c.maxWidth,
                  child: _ship(i),
                ),
            ],
          ),
        ),
        gap(30),
        const Eyebrow('LOADOUT'),
        gap(8),
        const Text(
          '장착 모듈',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        gap(12),
        for (int i = 0; i < equipmentOptions.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: InkWell(
              onTap: () => p.selectEquipment(i),
              borderRadius: BorderRadius.circular(18),
              child: Surface(
                active: p.equipment == i,
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 15,
                ),
                child: Row(
                  children: [
                    Icon(
                      i == 0
                          ? Icons.shield_outlined
                          : i == 1
                          ? Icons.bolt
                          : Icons.track_changes,
                      color: equipmentOptions[i].color,
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            equipmentOptions[i].name,
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          Text(
                            equipmentOptions[i].detail,
                            style: const TextStyle(color: muted, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    if (p.equipment == i)
                      const Icon(Icons.check_circle, color: cyan, size: 20),
                  ],
                ),
              ),
            ),
          ),
        gap(24),
        const Eyebrow('PERMANENT SYSTEMS'),
        gap(8),
        const Text(
          '영구 업그레이드',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        gap(12),
        _upgrade('attack', '증폭 회로', '모든 무기 공격력 +8% / 단계', Icons.bolt),
        gap(8),
        _upgrade('hull', '복합 장갑', '최대 내구도 +12% / 단계', Icons.shield_outlined),
        gap(8),
        _upgrade('magnet', '회수 안테나', '경험치 회수 범위 +15% / 단계', Icons.radar),
      ],
    ),
  );
  Widget _ship(int i) {
    final s = ships[i];
    final owned = p.unlockedShips.contains(i);
    return Surface(
      active: p.selectedShip == i,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Eyebrow('FRAME / 0${i + 1}', color: s.color),
              const Spacer(),
              if (p.selectedShip == i)
                const Icon(Icons.check_circle, color: cyan, size: 18),
            ],
          ),
          gap(10),
          Center(
            child: SizedBox(
              height: 120,
              child: Image.asset(
                s.asset,
                fit: BoxFit.contain,
                filterQuality: FilterQuality.medium,
                errorBuilder: (_, _, _) =>
                    Icon(Icons.rocket_launch, size: 70, color: s.color),
              ),
            ),
          ),
          Text(
            s.name,
            style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800),
          ),
          Text(s.tagline, style: TextStyle(color: s.color, fontSize: 12)),
          gap(12),
          Text(s.detail, style: const TextStyle(color: muted, fontSize: 12)),
          gap(16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Stat('${s.health.toInt()}', '내구도'),
              Stat('${s.speed.toInt()}', '기동력'),
              Stat('${(s.damage * 100).round()}%', '화력'),
            ],
          ),
          gap(18),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: owned
                  ? () => p.selectShip(i)
                  : p.credits >= s.unlockCost
                  ? () {
                      p.unlockShip(i);
                      p.selectShip(i);
                    }
                  : null,
              child: Text(
                owned
                    ? (p.selectedShip == i ? '선택됨' : '기체 선택')
                    : '${s.unlockCost} C · 해금',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _upgrade(String id, String title, String detail, IconData icon) {
    final level = p.upgradeLevel(id);
    final max = level >= maxUpgradeLevel;
    final cost = upgradeCost(level);
    return Surface(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: cyan),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$title  $level / $maxUpgradeLevel',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  detail,
                  style: const TextStyle(fontSize: 11, color: muted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: max || p.credits < cost ? null : () => p.buyUpgrade(id),
            child: Text(max ? 'MAX' : '$cost C'),
          ),
        ],
      ),
    );
  }

  Future<void> _settings(BuildContext context) => showDialog<void>(
    context: context,
    builder: (context) => StatefulBuilder(
      builder: (context, update) => AlertDialog(
        title: const Text('비행 설정'),
        content: SizedBox(
          width: 420,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('효과음'),
                  value: p.soundEnabled,
                  onChanged: (v) {
                    p.updateSettings(soundEnabled: v);
                    update(() {});
                  },
                ),
                Text(
                  '음량 ${(p.volume * 100).round()}%',
                  style: const TextStyle(color: muted),
                ),
                Slider(
                  value: p.volume,
                  label: '${(p.volume * 100).round()}%',
                  onChanged: (v) {
                    p.updateSettings(volume: v);
                    update(() {});
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('시각 효과 줄이기'),
                  subtitle: const Text('입자와 화면 효과를 줄입니다'),
                  value: p.reducedEffects,
                  onChanged: (v) {
                    p.updateSettings(reducedEffects: v);
                    update(() {});
                  },
                ),
                gap(16),
                const Text(
                  '진행은 이 기기에 자동 저장됩니다.\n브라우저 데이터 삭제 시 기록이 지워질 수 있습니다.\n진행 중인 전투는 저장되지 않습니다.',
                  style: TextStyle(color: muted, fontSize: 12),
                ),
                gap(16),
                const Text(
                  'SHOOTINGSTAR 1.0.0\n광고 · 결제 · 계정 없이 플레이',
                  style: TextStyle(color: muted, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => showLicensePage(
              context: context,
              applicationName: 'Shootingstar',
              applicationVersion: '1.0.0',
            ),
            child: const Text('오픈소스 라이선스'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('완료'),
          ),
        ],
      ),
    ),
  );
}
